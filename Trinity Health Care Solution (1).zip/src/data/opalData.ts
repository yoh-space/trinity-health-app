export type Language = 'am' | 'en';

export type CareStage =
  | 'none'
  | 'pregnancy'
  | 'breastfeeding'
  | 'caregiver'
  | 'prefer_not_to_say';

export type ScreenId =
  | 'welcome'
  | 'personalize'
  | 'home'
  | 'learn'
  | 'lesson-detail'
  | 'meals'
  | 'ask-opal'
  | 'care'
  | 'saved'
  | 'settings';

export type TopicId =
  | 'all'
  | 'pregnancy'
  | 'breastfeeding'
  | 'child_feeding'
  | 'food_safety'
  | 'water_hygiene';

export type MealAudience = 'family' | 'young_child';

export type AllergyId = 'none' | 'egg' | 'peanut' | 'dairy' | 'sesame';

export interface LessonSection {
  headingAm: string;
  headingEn: string;
  bodyAm: string;
  bodyEn: string;
  cueIcon: 'pot' | 'hands' | 'grain' | 'water' | 'spoon' | 'leaf';
}

export interface Lesson {
  id: string;
  topic: Exclude<TopicId, 'all'>;
  topicLabelAm: string;
  topicLabelEn: string;
  titleAm: string;
  titleEn: string;
  summaryAm: string;
  summaryEn: string;
  readTimeAm: string;
  readTimeEn: string;
  featuredToday?: boolean;
  relevantStages: CareStage[];
  sections: LessonSection[];
  keyTakeawayAm: string;
  keyTakeawayEn: string;
}

export interface IngredientItem {
  id: string;
  nameAm: string;
  nameEn: string;
  category: 'legume' | 'grain' | 'vegetable' | 'protein' | 'fruit';
}

export interface BundledRecipe {
  id: string;
  titleAm: string;
  titleEn: string;
  subtitleAm: string;
  subtitleEn: string;
  audiences: MealAudience[];
  matchedIngredients: string[];
  containsAllergens: AllergyId[];
  cookTimeAm: string;
  cookTimeEn: string;
  ingredientsListAm: string[];
  ingredientsListEn: string[];
  stepsAm: string[];
  stepsEn: string[];
  foodSafetyNoteAm: string;
  foodSafetyNoteEn: string;
}

export interface ConsultationRequestRecord {
  id: string;
  typeId: string;
  typeLabelAm: string;
  typeLabelEn: string;
  format: 'online' | 'in_person';
  formatLabelAm: string;
  formatLabelEn: string;
  createdAt: string;
  statusAm: string;
  statusEn: string;
}

export const CARE_STAGE_OPTIONS: {
  id: Exclude<CareStage, 'none'>;
  labelAm: string;
  labelEn: string;
  descAm: string;
  descEn: string;
}[] = [
  {
    id: 'pregnancy',
    labelAm: 'እርግዝና (Pregnancy)',
    labelEn: 'Pregnancy',
    descAm: 'ለነፍሰ ጡር እናቶች እና ለቤተሰብ የሚሆኑ የአመጋገብ ትምህርቶች',
    descEn: 'Practical everyday food and hydration lessons during pregnancy',
  },
  {
    id: 'breastfeeding',
    labelAm: 'ጡት ማጥባት / ከወሊድ በኋላ (Breastfeeding / postpartum)',
    labelEn: 'Breastfeeding / postpartum',
    descAm: 'ከወሊድ በኋላ እና ጡት በማጥባት ጊዜ የሚረዱ የምግብ ሀሳቦች',
    descEn: 'Supportive meal ideas and breastfeeding nutrition notes',
  },
  {
    id: 'caregiver',
    labelAm: 'የቤተሰብ ተንከባካቢ (Caregiver)',
    labelEn: 'Caregiver',
    descAm: 'ለህፃናት፣ ለአባቶች፣ ለአያቶች እና ለቤተሰብ ምግብ አዘጋጆች',
    descEn: 'For parents, grandparents, and family members preparing meals',
  },
  {
    id: 'prefer_not_to_say',
    labelAm: 'መግለጽ አልፈልግም (Prefer not to say)',
    labelEn: 'Prefer not to say',
    descAm: 'ሁሉንም አጠቃላይ የቤተሰብ የአመጋገብ ትምህርቶች ያሳያል',
    descEn: 'Browse all general household nutrition lessons without filtering',
  },
];

export const TOPICS: {
  id: TopicId;
  labelAm: string;
  labelEn: string;
}[] = [
  { id: 'all', labelAm: 'ሁሉም (All)', labelEn: 'All topics' },
  { id: 'pregnancy', labelAm: 'የእርግዝና አመጋገብ', labelEn: 'Pregnancy nutrition' },
  { id: 'breastfeeding', labelAm: 'ጡት ማጥባት', labelEn: 'Breastfeeding' },
  { id: 'child_feeding', labelAm: 'የህፃናት አመጋገብ', labelEn: 'Child feeding' },
  { id: 'food_safety', labelAm: 'የምግብ ደህንነት', labelEn: 'Food safety' },
  { id: 'water_hygiene', labelAm: 'ንጹህ ውሃ እና ንጽህና', labelEn: 'Clean water & hygiene' },
];

export const LESSONS: Lesson[] = [
  {
    id: 'lesson-food-safety-home',
    topic: 'food_safety',
    topicLabelAm: 'የምግብ ደህንነት · Food safety',
    topicLabelEn: 'Food safety',
    titleAm: 'በቤት ውስጥ የሚዘጋጅ ምግብን ደህንነት መጠበቅ',
    titleEn: 'Keeping Household Meals Safe to Eat',
    summaryAm: 'ምግብን በደንብ ማብሰል፣ ከድኖ ማስቀመጥ እና ከመመገብ በፊት እጅን መታጠብ ቤተሰብን ይጠብቃል።',
    summaryEn: 'Simple habits for cooking thoroughly, covering cooked food, and keeping utensils clean at home.',
    readTimeAm: '3 ደቂቃ ንባብ',
    readTimeEn: '3 min read',
    featuredToday: true,
    relevantStages: ['pregnancy', 'breastfeeding', 'caregiver', 'prefer_not_to_say', 'none'],
    sections: [
      {
        headingAm: '1. እጅን እና የማብሰያ ዕቃዎችን ማጽዳት',
        headingEn: '1. Clean Hands and Cooking Surfaces',
        bodyAm: 'ምግብ ከማዘጋጀትዎ በፊት እና ህፃናትን ከመመገብዎ በፊት እጅዎን በሳሙና እና በንጹህ ውሃ ይታጠቡ። የመክተፊያ ዕቃዎችን እና ቢላዎችን ከተጠቀሙ በኋላ ወዲያውኑ ይጠቡ።',
        bodyEn: 'Wash hands with soap and clean running or poured water before preparing food and before feeding young children. Rinse chopping boards and knives right after use.',
        cueIcon: 'hands',
      },
      {
        headingAm: '2. ምግብን በደንብ ማብሰል',
        headingEn: '2. Cook Food Thoroughly',
        bodyAm: 'ወጥ፣ እንቁላል፣ ሽሮ እና የህፃናት ገንፎ በደንብ እስኪበስሉ ድረስ በእሳት ላይ ያቆዩ። የተረፈ ምግብን እንደገና ሲጠቀሙ በደንብ እስኪፈላ ድረስ ያሙቁት።',
        bodyEn: 'Cook stews (wot), eggs, shiro, and porridges until steaming hot throughout. If reheating stored food, heat it until it bubbles and steams.',
        cueIcon: 'pot',
      },
      {
        headingAm: '3. የበሰለ ምግብን ከድኖ ማስቀመጥ',
        headingEn: '3. Cover Cooked Meals Promptly',
        bodyAm: 'የበሰለ ምግብን ከዝንቦች እና ከአቧራ ለመከላከል ሁልጊዜ በንጹህ ክዳን ይክደኑ። ምግብን ለብዙ ሰዓታት በሙቀት ውስጥ አይተዉ።',
        bodyEn: 'Always cover cooked dishes with a clean lid or cloth to protect them from flies and dust. Avoid leaving soft cooked foods sitting in warm air for many hours.',
        cueIcon: 'spoon',
      },
    ],
    keyTakeawayAm: 'ዋና ነጥብ፦ ንጹህ እጅ፣ በደንብ የበሰለ ምግብ እና የተከደነ ዕቃ ለቤተሰብ ጤና መሰረት ናቸው።',
    keyTakeawayEn: 'Key note: Clean hands, thorough cooking, and covered dishes help keep daily family meals safe.',
  },
  {
    id: 'lesson-pregnancy-plate',
    topic: 'pregnancy',
    topicLabelAm: 'የእርግዝና አመጋገብ · Pregnancy nutrition',
    topicLabelEn: 'Pregnancy nutrition',
    titleAm: 'በእርግዝና ጊዜ የተለያዩ የቤት ውስጥ ምግቦችን መመገብ',
    titleEn: 'Building a Varied Plate During Pregnancy',
    summaryAm: 'በቤት ውስጥ የሚገኙ ጥራጥሬዎችን፣ አረንጓዴ አትክልቶችን እና እህሎችን አቀናጅቶ የመመገብ ልምድ።',
    summaryEn: 'Combining familiar grains, pulses like lentils or chickpeas, and dark leafy greens across the week.',
    readTimeAm: '4 ደቂቃ ንባብ',
    readTimeEn: '4 min read',
    relevantStages: ['pregnancy', 'caregiver', 'prefer_not_to_say'],
    sections: [
      {
        headingAm: '1. የተለያዩ የምግብ ዓይነቶችን ማካተት',
        headingEn: '1. Combine Everyday Staple Foods',
        bodyAm: 'እንጀራ፣ ዳቦ ወይም አጃን ከምስር፣ ከሽሮ ወይም ከባቄላ ጋር አብሮ መመገብ ለሰውነት ጠቃሚ ነው። በየቀኑ አንድ ዓይነት ምግብ ብቻ ከመመገብ ይልቅ በቤት ውስጥ ያሉትን ማፈራረቅ ይረዳል።',
        bodyEn: 'Pairing everyday staples like teff injera, bread, or oats with legumes such as red lentils (misir) or chickpea shiro brings helpful variety to household meals.',
        cueIcon: 'grain',
      },
      {
        headingAm: '2. አረንጓዴ አትክልቶች እና ፍራፍሬዎች',
        headingEn: '2. Add Leafy Greens and Colorful Produce',
        bodyAm: 'ጎመን፣ ቆስጣ፣ ካሮት እና ዱባ በወጥ ወይም በጎን ምግብነት ማካተት ይመከራል። ከምግብ በኋላ እንደ ብርቱካን ወይም ሎሚ ያሉ ፍራፍሬዎችን መውሰድ ጠቃሚ ልምድ ነው።',
        bodyEn: 'Include dark leafy greens like gomen (collard greens) or swiss chard alongside carrots or pumpkin when available at the market.',
        cueIcon: 'leaf',
      },
      {
        headingAm: '3. ትንሽ ትንሽ በተደጋጋሚ መመገብ',
        headingEn: '3. Small, Frequent Meals When Tired or Nauseated',
        bodyAm: 'የምግብ ፍላጎት ሲቀንስ ወይም ማቅለሽለሽ ሲኖር፣ በአንድ ጊዜ ብዙ ከመብላት ይልቅ ቀለል ያሉ ምግቦችን (እንደ አጃ ገንፎ ወይም የተቀቀለ ድንች) ከፋፍሎ መመገብ ይቀላል።',
        bodyEn: 'If appetite feels low, eating smaller portions more often—such as warm oats porridge or boiled potato with mild stew—can feel gentler.',
        cueIcon: 'spoon',
      },
    ],
    keyTakeawayAm: 'ዋና ነጥብ፦ ይህ ትምህርት አጠቃላይ መረጃ ነው፤ በጤና ተቋም የሚሰጥዎትን የቅድመ ወሊድ ክትትል እና ምክር አይተካም።',
    keyTakeawayEn: 'Key note: This lesson shares general household ideas and does not replace antenatal visits or advice from a qualified clinician.',
  },
  {
    id: 'lesson-child-complementary',
    topic: 'child_feeding',
    topicLabelAm: 'የህፃናት አመጋገብ · Child feeding',
    topicLabelEn: 'Child feeding',
    titleAm: 'ለታዳጊ ህፃናት ለስላሳ እና የተሟላ ተጨማሪ ምግብ',
    titleEn: 'Soft, Mashed Meals for Growing Young Children',
    summaryAm: 'ከ6 ወር በኋላ ከጡት ወተት ጎን ለጎን የሚሰጡ ለስላሳ የቤተሰብ ምግቦች አዘገጃጀት።',
    summaryEn: 'Preparing thick, well-mashed porridges and soft family foods with patience and clean utensils.',
    readTimeAm: '3 ደቂቃ ንባብ',
    readTimeEn: '3 min read',
    relevantStages: ['breastfeeding', 'caregiver', 'prefer_not_to_say'],
    sections: [
      {
        headingAm: '1. ወፍራም እና በደንብ የተፈጨ ምግብ',
        headingEn: '1. Keep Porridge Thick Enough to Stay on the Spoon',
        bodyAm: 'ለህፃናት የሚዘጋጅ የአጃ፣ የጤፍ ወይም የድንች ምግብ በጣም ውሃ የበዛበት እንዳይሆን ይጠንቀቁ። በማንኪያ ሲወሰድ የማይፈስ ለስላሳ ውፍረት ቢኖረው ለህፃኑ የተሻለ ነው።',
        bodyEn: 'Very watery gruel fills a small stomach quickly without much nourishment. Mash cooked lentils, potato, carrot, or oats until soft and thick enough to hold on a spoon.',
        cueIcon: 'spoon',
      },
      {
        headingAm: '2. የተለያዩ ግብዓቶችን በትንሹ መቀላቀል',
        headingEn: '2. Mix Familiar Ingredients Gently',
        bodyAm: 'በገንፎ ወይም በተፈጨ ድንች ውስጥ በደንብ የበሰለ ምስር፣ የተከተፈ ጎመን ወይም የተፈጨ እንቁላል መጨመር ምግቡን ያበለጽጋል። ቅመም እና በርበሬ አይጨምሩ።',
        bodyEn: 'Stirring well-cooked red lentils, finely chopped cooked greens, or mashed hard-boiled egg into soft porridge adds variety without hot spices (berbere).',
        cueIcon: 'pot',
      },
    ],
    keyTakeawayAm: 'ዋና ነጥብ፦ ህፃናት አዲስ ምግብ ሲለምዱ በትዕግስት እና በንጹህ ማንኪያ ይመግቧቸው።',
    keyTakeawayEn: 'Key note: Feed young children slowly and patiently using a clean cup and spoon.',
  },
  {
    id: 'lesson-breastfeeding-hydration',
    topic: 'breastfeeding',
    topicLabelAm: 'ጡት ማጥባት · Breastfeeding',
    topicLabelEn: 'Breastfeeding',
    titleAm: 'ጡት በማጥባት ጊዜ የእናት አመጋገብ እና ፈሳሽ',
    titleEn: 'Nourishing the Caregiver During Breastfeeding',
    summaryAm: 'ጡት ለምታጠባ እናት በቂ ውሃ፣ ሙቅ ሾርባዎች እና ተደጋጋሚ ምግቦችን ማዘጋጀት።',
    summaryEn: 'Practical ways families can support a breastfeeding mother with regular meals and clean fluids.',
    readTimeAm: '3 ደቂቃ ንባብ',
    readTimeEn: '3 min read',
    relevantStages: ['breastfeeding', 'caregiver', 'pregnancy'],
    sections: [
      {
        headingAm: '1. ውሃ እና ሙቅ ፈሳሾችን በአቅራቢያ ማስቀመጥ',
        headingEn: '1. Keep Clean Water Within Easy Reach',
        bodyAm: 'ጡት ማጥባት ውሃ ጥም ሊያስከትል ይችላል። እናት ጡት በምታጠባበት ቦታ አጠገብ የተከደነ ንጹህ ውሃ ወይም የአጃ ሾርባ ማስቀመጥ ጥሩ የቤተሰብ ድጋፍ ነው።',
        bodyEn: 'Breastfeeding often brings natural thirst. Keeping a covered cup of safe drinking water or warm grain drink nearby helps the mother stay comfortable.',
        cueIcon: 'water',
      },
      {
        headingAm: '2. የቤተሰብ እገዛ በምግብ ዝግጅት',
        headingEn: '2. Family Support with Everyday Tasks',
        bodyAm: 'የቤተሰብ አባላት ምግብ በማብሰል፣ ውሃ በማቅረብ እና የቤት ስራን በመጋራት እናት እረፍት እንድታገኝ እና በሰዓቱ እንድትመገብ ማገዝ ይችላሉ።',
        bodyEn: 'Partners and family caregivers play an important role by preparing warm meals, boiling drinking water, and sharing household chores so the mother can rest and eat.',
        cueIcon: 'hands',
      },
    ],
    keyTakeawayAm: 'ዋና ነጥብ፦ ጡት ማጥባት ላይ ጥያቄ ወይም ህመም ካለ በአቅራቢያ ወደሚገኝ የጤና ባለሙያ ይሂዱ።',
    keyTakeawayEn: 'Key note: If breastfeeding is painful or you have concerns about your baby’s feeding, speak with a qualified health worker.',
  },
  {
    id: 'lesson-clean-water-hygiene',
    topic: 'water_hygiene',
    topicLabelAm: 'ንጹህ ውሃ እና ንጽህና · Clean water & hygiene',
    topicLabelEn: 'Clean water & hygiene',
    titleAm: 'የመጠጥ ውሃን በንጽህና ማዘጋጀት እና ማስቀመጥ',
    titleEn: 'Safe Drinking Water Storage at Home',
    summaryAm: 'ውሃን ማፍላት፣ በጠባብ አፍ ባለው ዕቃ ማስቀመጥ እና በንጹህ መቅጃ መጠቀም።',
    summaryEn: 'Boiling or treating household drinking water and storing it in covered, narrow-necked containers.',
    readTimeAm: '2 ደቂቃ ንባብ',
    readTimeEn: '2 min read',
    relevantStages: ['pregnancy', 'breastfeeding', 'caregiver', 'prefer_not_to_say'],
    sections: [
      {
        headingAm: '1. ውሃን በደንብ ማፍላት',
        headingEn: '1. Boil Water Until Rolling Bubbles Appear',
        bodyAm: 'የመጠጥ ውሃን ጥርጣሬ ካለዎት በደንብ እስኪፈላ ድረስ ያፍሉት። ከፈላ በኋላ በራሱ ጊዜ እንዲቀዘቅዝ ከድነው ያስቀምጡት።',
        bodyEn: 'Bringing drinking water to a full rolling boil and letting it cool under a clean cover is one of the most reliable ways to make water safer for the family.',
        cueIcon: 'water',
      },
      {
        headingAm: '2. የውሃ ማስቀመጫ ዕቃ ንጽህና',
        headingEn: '2. Use Covered, Clean Containers',
        bodyAm: 'የመጠጥ ውሃን ሁልጊዜ ክዳን ባለው ጀሪካን ወይም እንስራ ያስቀምጡ። እጅዎን ወደ ውሃው ውስጥ ከመክተት ይልቅ በማፍሰስ ወይም ረጅም እጀታ ባለው ንጹህ መቅጃ ይጠቀሙ።',
        bodyEn: 'Store safe water in a clean container with a lid. Pour water out or use a clean long-handled ladle so hands never touch the stored drinking water.',
        cueIcon: 'hands',
      },
    ],
    keyTakeawayAm: 'ዋና ነጥብ፦ ለህፃናት ምግብ እና መጠጥ የሚውል ውሃ ሁልጊዜ የተፈላ ወይም የታከመ መሆን አለበት።',
    keyTakeawayEn: 'Key note: Always use boiled or safely treated water when preparing food or drinks for infants and young children.',
  },
];

export const FAMILIAR_INGREDIENTS: IngredientItem[] = [
  { id: 'misir', nameAm: 'ምስር (Red lentils)', nameEn: 'Misir (Red lentils)', category: 'legume' },
  { id: 'shiro', nameAm: 'ሽሮ (Chickpea flour)', nameEn: 'Shiro (Chickpea flour)', category: 'legume' },
  { id: 'gomen', nameAm: 'ጎመን (Collard greens)', nameEn: 'Gomen (Collard greens)', category: 'vegetable' },
  { id: 'egg', nameAm: 'እንቁላል (Eggs)', nameEn: 'Eggs', category: 'protein' },
  { id: 'oats', nameAm: 'አጃ (Oats / Aja)', nameEn: 'Oats (Aja)', category: 'grain' },
  { id: 'potato', nameAm: 'ድንች (Potatoes)', nameEn: 'Potatoes', category: 'vegetable' },
  { id: 'carrot', nameAm: 'ካሮት (Carrots)', nameEn: 'Carrots', category: 'vegetable' },
  { id: 'avocado', nameAm: 'አቮካዶ (Avocado)', nameEn: 'Avocado', category: 'fruit' },
  { id: 'injera', nameAm: 'ጤፍ እንጀራ (Teff injera)', nameEn: 'Teff injera', category: 'grain' },
];

export const ALLERGY_OPTIONS: {
  id: AllergyId;
  labelAm: string;
  labelEn: string;
}[] = [
  { id: 'none', labelAm: 'ምንም አለርጂ የለም (No declared allergy)', labelEn: 'No declared allergy' },
  { id: 'egg', labelAm: 'እንቁላል (Egg allergy)', labelEn: 'Egg allergy' },
  { id: 'peanut', labelAm: 'ኦቾሎኒ / ለውዝ (Peanut / tree nut)', labelEn: 'Peanut / nut allergy' },
  { id: 'dairy', labelAm: 'ወተት እና የወተት ተዋጽኦ (Dairy / milk)', labelEn: 'Dairy / milk allergy' },
  { id: 'sesame', labelAm: 'ሰሊጥ (Sesame)', labelEn: 'Sesame allergy' },
];

export const BUNDLED_RECIPES: BundledRecipe[] = [
  {
    id: 'recipe-mild-misir-gomen',
    titleAm: 'አልጫ ምስር ከጎመን እና ድንች ጋር',
    titleEn: 'Mild Red Lentil (Alicha Misir) with Greens & Potato',
    subtitleAm: 'ለቤተሰብ ወይም በደንብ ተፈጭቶ ለህፃናት የሚሆን ቀለል ያለ የቤት ምግብ',
    subtitleEn: 'A gentle, non-spicy household stew using everyday lentils and vegetables',
    audiences: ['family', 'young_child'],
    matchedIngredients: ['misir', 'gomen', 'potato', 'carrot', 'injera'],
    containsAllergens: [],
    cookTimeAm: '25 ደቂቃ (25 mins)',
    cookTimeEn: '25 minutes',
    ingredientsListAm: [
      '1 ኩባያ የተለቀመ እና የታጠበ ምስር (Red lentils)',
      '1 እፍኝ በደቃቁ የተከተፈ ጎመን (Collard greens)',
      '1 መካከለኛ ድንች ወይም ካሮት በትንሹ የተከተፈ',
      'ትንሽ ሽንኩርት፣ የምግብ ዘይት እና ትንሽ እርድ (ያለ በርበሬ)',
      'ንጹህ ውሃ',
    ],
    ingredientsListEn: [
      '1 cup sorted and washed red lentils (misir)',
      '1 handful finely chopped gomen (collard greens)',
      '1 medium potato or carrot, diced small',
      'A little chopped onion, cooking oil, and a pinch of turmeric (no hot berbere)',
      'Clean water for simmering',
    ],
    stepsAm: [
      'ምስሩን፣ ድንቹን እና ጎመኑን በንጹህ ውሃ በደንብ ይጠቡ።',
      'ሽንኩርቱን በትንሽ ዘይት አቁላልተው ውሃ እና ምስሩን ይጨምሩ።',
      'ምስሩ መብሰል ሲጀምር የተከተፈውን ድንች/ካሮት እና ጎመን ይጨምሩ፤ ሁሉም በደንብ እስኪለሰልስ ድረስ ያብስሉት።',
      'ለታዳጊ ህፃን ከሆነ፦ ከማቅረብዎ በፊት በንጹህ ማንኪያ በደንብ ይፍጩት እና መቀዝቀዙን ያረጋግጡ።',
    ],
    stepsEn: [
      'Wash the red lentils, potato/carrot, and collard greens thoroughly in clean water.',
      'Soften the chopped onion in a little oil, then add clean water and the washed lentils.',
      'Once the lentils begin to soften, add the diced potato/carrot and finely chopped greens. Simmer until completely tender.',
      'For a young child: mash well with a clean spoon until smooth and thick, and let it cool to a safe warm temperature before serving.',
    ],
    foodSafetyNoteAm: 'የምግብ ደህንነት ማስታወሻ፦ ጎመንን ከመክተፍዎ በፊት በንጹህ ውሃ በደንብ ይጠቡ። የተረፈ ምግብን ከድነው ያስቀምጡ።',
    foodSafetyNoteEn: 'Food safety note: Wash leafy greens leaf by leaf in clean water before chopping. Keep cooked stew covered.',
  },
  {
    id: 'recipe-oats-carrot-porridge',
    titleAm: 'ወፍራም የአጃ (Oats) እና የካሮት/አቮካዶ ገንፎ',
    titleEn: 'Warm Oats (Aja) Porridge with Soft Carrot or Avocado',
    subtitleAm: 'ለታዳጊ ህፃናት እና ለቤተሰብ ቁርስ ተስማሚ የሆነ ለስላሳ ምግብ',
    subtitleEn: 'A thick, comforting spoonable meal prepared with clean water',
    audiences: ['young_child', 'family'],
    matchedIngredients: ['oats', 'carrot', 'avocado'],
    containsAllergens: [],
    cookTimeAm: '15 ደቂቃ (15 mins)',
    cookTimeEn: '15 minutes',
    ingredientsListAm: [
      '1 ኩባያ የአጃ ዱቄት ወይም የተፈጨ አጃ (Oats / Aja)',
      '1 በደቃቁ የተፈቀፈቀ ካሮት ወይም የበሰለ አቮካዶ',
      '2.5 ኩባያ ንጹህ ውሃ',
      'ትንሽ የምግብ ዘይት',
    ],
    ingredientsListEn: [
      '1 cup oats flour or rolled oats (aja)',
      '1 finely grated carrot (cooked soft) or ripe mashed avocado',
      '2.5 cups clean water',
      'A few drops of cooking oil',
    ],
    stepsAm: [
      'የአጃ ዱቄቱን ከንጹህ ውሃ እና ከተፈቀፈቀው ካሮት ጋር በድስት ውስጥ ይቀላቅሉ።',
      'እያማሰሉ ለ10–12 ደቂቃ በደንብ እስኪበስል እና ወፍራም እስኪሆን ድረስ ያብስሉት።',
      'አቮካዶ የሚጠቀሙ ከሆነ፣ ገንፎው ከበሰለ እና ትንሽ ከቀዘቀዘ በኋላ በደንብ ፈጭተው ይቀላቅሉት።',
    ],
    stepsEn: [
      'Combine the oats and finely grated carrot with clean water in a clean pot.',
      'Simmer gently while stirring for 10–12 minutes until bubbling and thick enough to stay on a spoon.',
      'If using ripe avocado, wash the outside before cutting and mash it into the warm porridge just before serving.',
    ],
    foodSafetyNoteAm: 'የምግብ ደህንነት ማስታወሻ፦ ለህፃናት የተዘጋጀ ገንፎን ወዲያውኑ ይመግቡ፤ ለብዙ ሰዓት የተቀመጠ ገንፎን እንደገና ለህፃን አይስጡ።',
    foodSafetyNoteEn: 'Food safety note: Serve porridge freshly cooked in a clean bowl. Avoid keeping leftover infant porridge at room temperature.',
  },
  {
    id: 'recipe-shiro-egg-family',
    titleAm: 'ለስላሳ ሽሮ ወጥ ከተቀቀለ እንቁላል እና ጎመን ጋር',
    titleEn: 'Gentle Household Shiro with Hard-Boiled Egg & Greens',
    subtitleAm: 'በቤት ውስጥ በቀላሉ የሚገኙ ግብዓቶችን ያቀናጀ የቤተሰብ ማዕድ',
    subtitleEn: 'A familiar Ethiopian household meal pairing chickpea shiro with cooked egg',
    audiences: ['family', 'young_child'],
    matchedIngredients: ['shiro', 'egg', 'gomen', 'injera'],
    containsAllergens: ['egg'],
    cookTimeAm: '20 ደቂቃ (20 mins)',
    cookTimeEn: '20 minutes',
    ingredientsListAm: [
      'ግማሽ ኩባያ የሽሮ ዱቄት (Chickpea shiro)',
      '1 ወይም 2 እንቁላል (በደንብ የተቀቀለ)',
      '1 እፍኝ የበሰለ ጎመን (Collard greens)',
      'ንጹህ ውሃ፣ ትንሽ ሽንኩርት እና የምግብ ዘይት',
    ],
    ingredientsListEn: [
      '1/2 cup chickpea shiro flour',
      '1–2 eggs, hard-boiled until firm throughout',
      '1 handful washed and steamed gomen (collard greens)',
      'Clean water, chopped onion, and a little oil',
    ],
    stepsAm: [
      'እንቁላሉን በንጹህ ውሃ ውስጥ አስገብተው ውሃው ከፈላ በኋላ ለ10 ደቂቃ በደንብ እስኪጠነክር ድረስ ይቀቅሉት።',
      'በሌላ ድስት ሽንኩርት እና ውሃ ጥደው የሽሮ ዱቄቱን እያማሰሉ ይጨምሩ፤ በደንብ እስኪበስል ያቆዩት (ሽሮ ቶሎ ስለሚፈላ እሳት ይቀንሱ)።',
      'ለህፃን ሲያቀርቡ የተቀቀለውን እንቁላል አስኳል እና ነጩን በደንብ ፈጭተው ከለስላሳ ሽሮ ጋር ያዋህዱ።',
    ],
    stepsEn: [
      'Boil the eggs in water for a full 10 minutes so both the white and yolk are completely firm.',
      'Simmer chopped onion with water and whisk in the shiro flour. Cook gently until smooth and thoroughly cooked (10–15 minutes).',
      'Serve alongside steamed greens and injera, or mash the cooked egg into mild shiro for young children.',
    ],
    foodSafetyNoteAm: 'የምግብ ደህንነት ማስታወሻ፦ እንቁላል ሳይበስል (ጥሬውን) በፍጹም አይጠቀሙ፤ ውስጡ ሙሉ በሙሉ እስኪጠነክር ይቀቅሉት።',
    foodSafetyNoteEn: 'Food safety note: Always cook eggs until both the white and yolk are completely firm—never serve raw or runny eggs to pregnant women or young children.',
  },
];

export interface AskOpalPrompt {
  id: string;
  questionAm: string;
  questionEn: string;
  scope: 'in_scope' | 'out_of_scope';
  answerAm: string;
  answerEn: string;
  sourceLessonId?: string;
  sourceLabelAm?: string;
  sourceLabelEn?: string;
  actionType?: 'open_lesson' | 'open_meals';
}

export const ASK_OPAL_PROMPTS: AskOpalPrompt[] = [
  {
    id: 'q-food-safety',
    questionAm: 'ስለ ምግብ ደህንነት ትምህርት አሳየኝ (Show me a food-safety lesson)',
    questionEn: 'Show me a food-safety lesson',
    scope: 'in_scope',
    answerAm:
      'ከኦፓል የቤት ውስጥ ማስታወሻዎች የተገኘ፦ ምግብ ከማዘጋጀትዎ እና ከመመገብዎ በፊት እጅን በሳሙና መታጠብ፣ ወጥ እና እንቁላልን በደንብ ማብሰል፣ እንዲሁም የበሰለ ምግብን ከዝንብ እና አቧራ ከድኖ ማስቀመጥ ዋና ዋና የምግብ ደህንነት ልምዶች ናቸው።',
    answerEn:
      'From Opal Care’s bundled learning notes: Washing hands with soap before cooking and feeding, cooking stews and eggs thoroughly until steaming hot, and covering cooked dishes right away are practical ways to protect household meals.',
    sourceLessonId: 'lesson-food-safety-home',
    sourceLabelAm: 'ምንጭ፦ የሙከራ ትምህርት — «በቤት ውስጥ የሚዘጋጅ ምግብን ደህንነት መጠበቅ»',
    sourceLabelEn: 'Bundled source: Prototype lesson — "Keeping Household Meals Safe to Eat"',
    actionType: 'open_lesson',
  },
  {
    id: 'q-ingredients',
    questionAm: 'በቤት ውስጥ ባሉ ግብዓቶች ምን መስራት እችላለሁ? (What can I make with these ingredients?)',
    questionEn: 'What can I make with these ingredients?',
    scope: 'in_scope',
    answerAm:
      'በቤትዎ ያሉትን ግብዓቶች (ለምሳሌ ምስር፣ ሽሮ፣ ጎመን፣ አጃ፣ ድንች ወይም እንቁላል) በመምረጥ «የምግብ ሀሳብ አጋዥ» ገጽ ላይ ለቤተሰብ ወይም ለታዳጊ ህፃን የሚሆን ቀላል የአዘገጃጀት ሀሳብ ማየት ይችላሉ። አለርጂ ካለም አስቀድመው ማሳወቅ ይችላሉ።',
    answerEn:
      'You can use the Meal Idea Helper to select ingredients you already have at home—such as red lentils (misir), shiro, gomen, oats, or potatoes—declare any allergies, and view a bundled general recipe with food-safety steps.',
    sourceLabelAm: 'ምንጭ፦ የኦፓል የምግብ ሀሳብ አጋዥ (Bundled Meal Idea Helper)',
    sourceLabelEn: 'Bundled source: Opal Care Meal Idea Helper',
    actionType: 'open_meals',
  },
  {
    id: 'q-water',
    questionAm: 'የመጠጥ ውሃን በቤት ውስጥ እንዴት በንጽህና ማስቀመጥ ይቻላል?',
    questionEn: 'How do I keep drinking water safe at home?',
    scope: 'in_scope',
    answerAm:
      'ከኦፓል የውሃ እና ንጽህና ትምህርት፦ የመጠጥ ውሃን በደንብ እስኪፈላ ድረስ ማፍላት፣ በንጹህ እና ክዳን ባለው ዕቃ ማስቀመጥ፣ እና ውሃውን ሲቀዱ እጅ እንዳይነካው በማፍሰስ ወይም በንጹህ መቅጃ መጠቀም ይመከራል።',
    answerEn:
      'From Opal Care’s bundled water & hygiene lesson: Bring drinking water to a full rolling boil, let it cool under a clean cover, and store it in a closed container. Pour water out rather than dipping cups or hands inside.',
    sourceLessonId: 'lesson-clean-water-hygiene',
    sourceLabelAm: 'ምንጭ፦ የሙከራ ትምህርት — «የመጠጥ ውሃን በንጽህና ማዘጋጀት እና ማስቀመጥ»',
    sourceLabelEn: 'Bundled source: Prototype lesson — "Safe Drinking Water Storage at Home"',
    actionType: 'open_lesson',
  },
  {
    id: 'q-out-of-scope',
    questionAm: 'ልጄ ትኩሳት አለው፣ ምን መድኃኒት ልስጠው? (Out-of-scope clinical question)',
    questionEn: 'My child has a fever or illness—what medicine or treatment should I give?',
    scope: 'out_of_scope',
    answerAm:
      'ለዚህ ጥያቄ የተገመገመ መረጃ የለኝም (I don’t have reviewed information for that)። ኦፓል በዚህ መተግበሪያ ውስጥ የተካተቱ አጠቃላይ የአመጋገብ እና የንጽህና ትምህርቶችን ብቻ ያካፍላል። ለህመም ምልክቶች፣ ለመድኃኒት ወይም ለህክምና ምክር እባክዎ በአቅራቢያዎ የሚገኝ ብቁ የጤና ባለሙያን ወይም የጤና ተቋምን ያማክሩ።',
    answerEn:
      'I don’t have reviewed information for that. Opal Care only shares general educational notes bundled inside this prototype and cannot assess symptoms, diagnose illness, or recommend medicines. Please speak with a qualified health professional or visit a local health facility.',
    sourceLabelAm: 'የደህንነት ወሰን፦ ከተካተቱት ትምህርቶች ውጭ የሆነ ጥያቄ',
    sourceLabelEn: 'Safety boundary: Question is outside bundled learning content',
  },
];

export const CONSULTATION_TYPES = [
  {
    id: 'general_family',
    labelAm: 'አጠቃላይ የቤተሰብ አመጋገብ (General family nutrition)',
    labelEn: 'General family nutrition',
    descAm: 'በቤት ውስጥ በሚገኙ ግብዓቶች የተመጣጠነ የቤተሰብ ምግብ ስለማዘጋጀት',
    descEn: 'Questions about everyday household meals and food safety',
  },
  {
    id: 'maternal_nutrition',
    labelAm: 'የእርግዝና እና ጡት ማጥባት አመጋገብ (Pregnancy & breastfeeding)',
    labelEn: 'Pregnancy & breastfeeding nutrition',
    descAm: 'በእርግዝና ወይም ጡት በማጥባት ጊዜ ስለሚያስፈልጉ አጠቃላይ የአመጋገብ ልምዶች',
    descEn: 'General nutrition educational support during pregnancy or postpartum',
  },
  {
    id: 'child_feeding_consult',
    labelAm: 'የታዳጊ ህፃናት ተጨማሪ ምግብ (Young child feeding)',
    labelEn: 'Young child feeding guidance',
    descAm: 'ለህፃናት ለስላሳ እና የተለያዩ ምግቦችን ስለማስለመድ',
    descEn: 'Guidance on preparing soft complementary foods at home',
  },
];
