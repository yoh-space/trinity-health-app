import type { ProfileContext } from '../lib/profile';

export type StaffStatus = 'new' | 'in_review' | 'assigned' | 'scheduled' | 'completed' | 'declined';
export type StaffRole = 'counselor' | 'clinician' | 'admin';

export interface TimelineEntry {
  label: string;
  at: string;
}

export interface QueueItem {
  id: string;
  source: 'seed' | 'family';
  typeId: string;
  format: 'online' | 'in_person';
  received: string;
  status: StaffStatus;
  assignee?: string;
  slot?: string;
  note: string;
  timeline: TimelineEntry[];
  profileContext?: ProfileContext;
}

export interface StaffMember {
  id: string;
  name: string;
  role: Exclude<StaffRole, 'admin'>;
  title: string;
  specialty: string;
  isNew?: boolean;
}

export const PERSONA: Record<StaffRole, string | null> = { counselor: 'Selam T.', clinician: 'Dr. Abel M.', admin: null };
export const SPECIALTIES = ['Family & child feeding', 'Pregnancy & breastfeeding', 'Diabetes & hypertension education', 'Counseling & lifestyle support'];
export const ROLE_TITLE: Record<Exclude<StaffRole, 'admin'>, string> = { counselor: 'Nutrition counselor', clinician: 'Clinician' };

export const STAFF_ROLES: { id: StaffRole; label: string; hint: string }[] = [
  { id: 'counselor', label: 'Counselor', hint: 'Nutrition & education' },
  { id: 'clinician', label: 'Clinician', hint: 'NCD & therapy' },
  { id: 'admin', label: 'Admin', hint: 'Queue & team' },
];

export const STAFF_STATUS: Record<StaffStatus, { label: string; tone: string }> = {
  new: { label: 'New', tone: 'amber' },
  in_review: { label: 'In review', tone: 'green' },
  assigned: { label: 'Assigned', tone: 'teal' },
  scheduled: { label: 'Scheduled', tone: 'blue' },
  completed: { label: 'Completed', tone: 'grey' },
  declined: { label: 'Declined', tone: 'red' },
};

export const WORKFLOW: { status: StaffStatus; label: string }[] = [
  { status: 'new', label: 'Received' },
  { status: 'in_review', label: 'Review' },
  { status: 'assigned', label: 'Assign' },
  { status: 'scheduled', label: 'Schedule' },
  { status: 'completed', label: 'Complete' },
];

export const STAFF_TEAM: StaffMember[] = [
  { id: 'st-1', name: 'Selam T.', role: 'counselor', title: 'Nutrition counselor', specialty: 'Family & child feeding' },
  { id: 'st-2', name: 'Dr. Abel M.', role: 'clinician', title: 'Clinician', specialty: 'Diabetes & hypertension education' },
  { id: 'st-3', name: 'Hanna G.', role: 'clinician', title: 'Therapist', specialty: 'Counseling & lifestyle support' },
];

export const SLOTS = ['Tomorrow · 10:00', 'Thursday · 14:30', 'Friday · 09:00'];

export const SEED_QUEUE: QueueItem[] = [
  {
    id: 'REQ-1046', source: 'seed', typeId: 'child_feeding_consult', format: 'online', received: 'Today · 08:40', status: 'new',
    note: '', timeline: [{ label: 'Request received', at: '08:40' }],
  },
  {
    id: 'REQ-1045', source: 'seed', typeId: 'general_family', format: 'in_person', received: 'Today · 07:55', status: 'in_review',
    note: 'Family asked about balanced weekday meals.',
    timeline: [{ label: 'Request received', at: '07:55' }, { label: 'Review started', at: '08:10' }],
  },
  {
    id: 'REQ-1043', source: 'seed', typeId: 'maternal_nutrition', format: 'online', received: 'Yesterday · 16:20', status: 'scheduled',
    assignee: 'Selam T.', slot: 'Thursday · 14:30', note: 'Share the pregnancy plate lesson before the session.',
    timeline: [{ label: 'Request received', at: '16:20' }, { label: 'Review started', at: '16:45' }, { label: 'Assigned to Selam T.', at: '17:05' }, { label: 'Scheduled · Thursday 14:30', at: '17:10' }],
  },
  {
    id: 'REQ-1041', source: 'seed', typeId: 'general_family', format: 'online', received: 'Mon · 11:05', status: 'completed',
    assignee: 'Dr. Abel M.', slot: 'Mon · 15:00', note: 'Session complete. Education materials shared.',
    timeline: [{ label: 'Request received', at: '11:05' }, { label: 'Assigned to Dr. Abel M.', at: '11:30' }, { label: 'Scheduled · Mon 15:00', at: '11:35' }, { label: 'Completed', at: '15:40' }],
  },
  {
    id: 'REQ-1044', source: 'seed', typeId: 'general_family', format: 'online', received: 'Yesterday · 10:10', status: 'scheduled',
    assignee: 'Dr. Abel M.', slot: 'Tomorrow · 10:00', note: 'Family interested in lower-salt cooking and daily activity.',
    timeline: [{ label: 'Request received', at: '10:10' }, { label: 'Assigned to Dr. Abel M.', at: '10:40' }, { label: 'Scheduled · Tomorrow 10:00', at: '10:45' }],
  },
  {
    id: 'REQ-1042', source: 'seed', typeId: 'child_feeding_consult', format: 'in_person', received: 'Yesterday · 09:30', status: 'assigned',
    assignee: 'Selam T.', note: '', timeline: [{ label: 'Request received', at: '09:30' }, { label: 'Assigned to Selam T.', at: '09:50' }],
  },
];
