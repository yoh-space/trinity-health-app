import type { CareStage } from '../data/opalData';

export interface Profile {
  forWho: string;
  age: string;
  conditions: string[];
  meals: string;
  activity: string;
  diet: string[];
  goals: string[];
  format: string;
  customSupport: string;
  customGoal: string;
  customFormat: string;
}

export interface ProfileContext {
  entries: { label: string; value: string }[];
}

export const EMPTY_PROFILE: Profile = { forWho: '', age: '', conditions: [], meals: '', activity: '', diet: [], goals: [], format: '', customSupport: '', customGoal: '', customFormat: '' };

export interface Option { id: string; am: string; en: string; hintAm?: string; hintEn?: string }

export const FOR_WHO: Option[] = [
  { id: 'self', am: 'ለራሴ', en: 'Myself' },
  { id: 'child', am: 'ለልጄ', en: 'My child' },
  { id: 'family', am: 'ለቤተሰቤ', en: 'My whole family' },
  { id: 'care', am: 'ለምከባከበው ሰው', en: 'Someone I care for' },
];
export const AGES: Option[] = [
  { id: 'u5', am: 'ከ5 በታች', en: 'Under 5' },
  { id: '5-17', am: '5–17', en: '5–17' },
  { id: '18-39', am: '18–39', en: '18–39' },
  { id: '40-59', am: '40–59', en: '40–59' },
  { id: '60+', am: '60+', en: '60+' },
];
export const CONDITIONS: Option[] = [
  { id: 'diabetes', am: 'ስኳር በሽታ', en: 'Diabetes', hintAm: 'ወይም ከፍተኛ የደም ስኳር', hintEn: 'or high blood sugar' },
  { id: 'hypertension', am: 'የደም ግፊት', en: 'High blood pressure' },
  { id: 'heart', am: 'የልብ ጤና', en: 'Heart health' },
  { id: 'weight', am: 'የክብደት አያያዝ', en: 'Weight management' },
  { id: 'pregnancy', am: 'እርግዝና', en: 'Pregnancy' },
  { id: 'breastfeeding', am: 'ጡት ማጥባት', en: 'Breastfeeding' },
  { id: 'child', am: 'የልጆች አመጋገብ', en: 'Child nutrition' },
  { id: 'mental', am: 'ጭንቀትና ደህንነት', en: 'Stress & wellbeing' },
];
export const MEALS: Option[] = [
  { id: '1-2', am: '1–2', en: '1–2' }, { id: '3', am: '3', en: '3' }, { id: '4+', am: '4+', en: '4 or more' },
];
export const ACTIVITY: Option[] = [
  { id: 'low', am: 'ቀላል', en: 'Mostly seated', hintAm: 'አብዛኛው ጊዜ ተቀምጦ', hintEn: 'Little daily movement' },
  { id: 'moderate', am: 'መካከለኛ', en: 'Moderately active', hintAm: 'አዘውትሮ መራመድ', hintEn: 'Regular walking or chores' },
  { id: 'high', am: 'ንቁ', en: 'Very active', hintAm: 'አካላዊ ሥራ ወይም ስፖርት', hintEn: 'Physical work or exercise' },
];
export const DIET: Option[] = [
  { id: 'fasting', am: 'የጾም ምግብ', en: 'Fasting days' },
  { id: 'plant', am: 'በአብዛኛው ዕፅዋት', en: 'Mostly plant-based' },
  { id: 'allergy', am: 'የምግብ አለርጂ', en: 'Food allergies' },
  { id: 'budget', am: 'ዋጋ ቆጣቢ', en: 'Budget-minded' },
];
export const GOALS: Option[] = [
  { id: 'learn', am: 'ጤናማ አመጋገብ መማር', en: 'Learn healthy eating' },
  { id: 'manage', am: 'የሥር የሰደደ ሕመም ድጋፍ', en: 'Support for a long-term condition' },
  { id: 'therapy', am: 'የአመጋገብ ቴራፒ', en: 'Nutrition therapy' },
  { id: 'consult', am: 'ከባለሙያ ጋር መነጋገር', en: 'Talk to a professional' },
  { id: 'family', am: 'ለቤተሰብ ምግብ ማቀድ', en: 'Plan family meals' },
];
export const FORMATS: Option[] = [
  { id: 'online', am: 'በበይነመረብ', en: 'Online' },
  { id: 'in_person', am: 'በአካል', en: 'In person' },
  { id: 'either', am: 'ሁለቱም ደህና ነው', en: 'Either works' },
];

const ids = (list: Option[]) => list.map(item => item.id);
const one = (value: unknown, list: Option[]) => typeof value === 'string' && ids(list).includes(value) ? value : '';
const many = (value: unknown, list: Option[]) => Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string' && ids(list).includes(item)) : [];
const customSupport = (value: unknown) => typeof value === 'string' ? value.replace(/\s+/g, ' ').trim().slice(0, 120) : '';

export function sanitizeProfile(value: unknown): Profile | null {
  if (!value || typeof value !== 'object') return null;
  const v = value as Record<string, unknown>;
  return {
    forWho: one(v.forWho, FOR_WHO), age: one(v.age, AGES), conditions: many(v.conditions, CONDITIONS), meals: one(v.meals, MEALS),
    activity: one(v.activity, ACTIVITY), diet: many(v.diet, DIET), goals: many(v.goals, GOALS), format: one(v.format, FORMATS),
    customSupport: customSupport(v.customSupport), customGoal: customSupport(v.customGoal), customFormat: customSupport(v.customFormat),
  };
}

export function stageFromProfile(profile: Profile): CareStage {
  if (profile.conditions.includes('pregnancy')) return 'pregnancy';
  if (profile.conditions.includes('breastfeeding')) return 'breastfeeding';
  if (profile.conditions.includes('child') || profile.forWho === 'child' || profile.forWho === 'family') return 'caregiver';
  return 'none';
}

export const labelOf = (list: Option[], id: string, lang: 'am' | 'en') => {
  const item = list.find(entry => entry.id === id);
  return item ? item[lang] : id;
};

export function profileContext(profile: Profile | null): ProfileContext | undefined {
  if (!profile) return undefined;
  const values = (list: Option[], ids: string[]) => ids.map(id => labelOf(list, id, 'en')).join(', ');
  const entries = [
    { label: 'For', value: profile.forWho && labelOf(FOR_WHO, profile.forWho, 'en') },
    { label: 'Age range', value: profile.age && labelOf(AGES, profile.age, 'en') },
    { label: 'Support topics', value: values(CONDITIONS, profile.conditions) },
    { label: 'Meals each day', value: profile.meals && labelOf(MEALS, profile.meals, 'en') },
    { label: 'Daily activity', value: profile.activity && labelOf(ACTIVITY, profile.activity, 'en') },
    { label: 'Food preferences', value: values(DIET, profile.diet) },
    { label: 'Goals', value: values(GOALS, profile.goals) },
    { label: 'Other goal', value: profile.customGoal },
    { label: 'Other format preference', value: profile.customFormat },
    { label: 'Other support topic', value: profile.customSupport },
  ].filter((entry): entry is { label: string; value: string } => Boolean(entry.value));
  return entries.length ? { entries } : undefined;
}
