import { LESSONS, type Language } from '../data/opalData';
import { sanitizeProfile, type Profile } from './profile';

const KEY = 'opal-care-preferences-v1';
export interface Preferences {
  lang: Language;
  welcomed: boolean;
  saved: string[];
  profile: Profile | null;
}

export const freshPreferences = (): Preferences => ({ lang: 'am', welcomed: false, saved: [], profile: null });

export function readPreferences(): Preferences {
  try {
    const value = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (!value || typeof value !== 'object') return freshPreferences();
    return {
      lang: value.lang === 'en' ? 'en' : 'am',
      welcomed: value.welcomed === true,
      saved: Array.isArray(value.saved)
        ? [...new Set<string>(value.saved.filter((id: unknown) =>
          typeof id === 'string' && LESSONS.some(lesson => lesson.id === id)))]
        : [],
      profile: sanitizeProfile(value.profile),
    };
  } catch {
    return freshPreferences();
  }
}

export function writePreferences(preferences: Preferences): boolean {
  try {
    localStorage.setItem(KEY, JSON.stringify(preferences));
    return true;
  } catch {
    return false;
  }
}

export function clearPreferences(): boolean {
  try {
    localStorage.removeItem(KEY);
    return true;
  } catch {
    return false;
  }
}
