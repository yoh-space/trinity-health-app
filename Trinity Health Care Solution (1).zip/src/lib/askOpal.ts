export type OpalReply =
  | { kind: 'welcome' }
  | { kind: 'prompt'; promptId: string }
  | { kind: 'lesson'; lessonId: string }
  | { kind: 'warning' }
  | { kind: 'handover' }
  | { kind: 'handed' }
  | { kind: 'fallback' };

export interface ChatMessage {
  id: number;
  from: 'user' | 'opal';
  text?: string;
  reply?: OpalReply;
}

export const INITIAL_CHAT: ChatMessage[] = [{ id: 0, from: 'opal', reply: { kind: 'welcome' } }];

const WARNING_TERMS = [
  'fever', 'bleeding', 'blood', 'seizure', 'convuls', 'unconscious', 'faint', 'breath', 'severe', 'chest pain',
  'vomit', 'diarrh', 'dehydrat', 'swelling', 'swollen', 'not moving', 'less movement', 'poison', 'emergency',
  'urgent', 'yellow', 'burn', 'pain', 'sick', 'medicine', 'medication', 'pill', 'dose', 'treat', 'infection',
  'ትኩሳት', 'ደም', 'መንቀጥቀጥ', 'ራስን መሳት', 'መሳት', 'መተንፈስ', 'ከባድ', 'ትውከት', 'ማስመለስ', 'ተቅማጥ', 'ድንገተኛ',
  'አስቸኳይ', 'መርዝ', 'እብጠት', 'ህመም', 'ሕመም', 'ታሟል', 'ታማ', 'መድኃኒት', 'መድሃኒት', 'ኢንፌክሽን',
];

const HANDOVER_TERMS = [
  'consult', 'nutritionist', 'dietitian', 'professional', 'expert', 'talk to', 'speak to', 'real person', 'appointment', 'book',
  'ባለሙያ', 'ምክክር', 'ቀጠሮ', 'ማነጋገር',
];

const LESSON_TOPICS: { lessonId: string; terms: string[] }[] = [
  { lessonId: 'lesson-pregnancy-plate', terms: ['pregnan', 'expecting', 'እርግዝና', 'ነፍሰ ጡር', 'እርጉዝ'] },
  { lessonId: 'lesson-breastfeeding-hydration', terms: ['breastfe', 'nursing', 'lactat', 'ጡት'] },
  { lessonId: 'lesson-child-complementary', terms: ['baby', 'toddler', 'infant', 'child', 'complementary', 'porridge', 'weaning', 'ህፃን', 'ሕፃን', 'ልጅ', 'ተጨማሪ ምግብ', 'ገንፎ'] },
];

const PROMPT_TOPICS: { promptId: string; terms: string[] }[] = [
  { promptId: 'q-water', terms: ['water', 'boil', 'drink', 'ውሃ', 'ውኃ', 'መጠጥ', 'ማፍላት'] },
  { promptId: 'q-ingredients', terms: ['ingredient', 'recipe', 'meal', 'cook with', 'make with', 'lentil', 'misir', 'shiro', 'gomen', 'oats', 'potato', 'allerg', 'ግብዓት', 'አዘገጃጀት', 'ምስር', 'ሽሮ', 'ጎመን', 'አጃ', 'ድንች', 'አለርጂ', 'ምግብ ሀሳብ'] },
  { promptId: 'q-food-safety', terms: ['food safety', 'safe', 'wash', 'hand', 'hygiene', 'germ', 'egg', 'clean', 'ደህንነት', 'እጅ', 'እንቁላል', 'ንጽህና', 'ንፅህና'] },
];

const has = (text: string, terms: string[]) => terms.some(term => text.includes(term));

export function matchQuestion(raw: string): OpalReply {
  const text = raw.toLowerCase().trim();
  if (has(text, WARNING_TERMS)) return { kind: 'warning' };
  if (has(text, HANDOVER_TERMS)) return { kind: 'handover' };
  const lesson = LESSON_TOPICS.find(topic => has(text, topic.terms));
  if (lesson) return { kind: 'lesson', lessonId: lesson.lessonId };
  const prompt = PROMPT_TOPICS.find(topic => has(text, topic.terms));
  if (prompt) return { kind: 'prompt', promptId: prompt.promptId };
  return { kind: 'fallback' };
}
