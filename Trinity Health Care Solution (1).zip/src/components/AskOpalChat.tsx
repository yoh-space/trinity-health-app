import { useEffect, useRef, useState, type Dispatch, type FormEvent, type SetStateAction } from 'react';
import { ArrowRight, Check, HeartHandshake, Loader2, SendHorizontal, Siren } from 'lucide-react';
import { ASK_OPAL_PROMPTS, CONSULTATION_TYPES, LESSONS, type Language, type ScreenId } from '../data/opalData';
import { matchQuestion, type ChatMessage, type OpalReply } from '../lib/askOpal';
import { Button, Choice, Heading, type Translate } from './OpalUI';
import trinityMark from '../assets/trinity-mark.png';
import type { DemoRequest } from './SecondaryScreens';

interface Props {
  lang: Language;
  t: Translate;
  chat: ChatMessage[];
  setChat: Dispatch<SetStateAction<ChatMessage[]>>;
  request: DemoRequest | null;
  setRequest: (request: DemoRequest | null) => void;
  navigate: (screen: ScreenId) => void;
  openLesson: (id: string) => void;
}

const SUGGESTIONS = ['q-food-safety', 'q-water', 'q-ingredients'];

export default function AskOpalScreen(props: Props) {
  const { lang, t, chat, setChat, request, navigate } = props;
  const [draft, setDraft] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chat.length > 1) endRef.current?.scrollIntoView({ block: 'end', behavior: 'smooth' });
  }, [chat.length]);

  function ask(text: string, reply: OpalReply = matchQuestion(text)) {
    const clean = text.trim();
    if (!clean) return;
    setChat(previous => {
      const next = previous[previous.length - 1].id + 1;
      return [...previous, { id: next, from: 'user', text: clean }, { id: next + 1, from: 'opal', reply }];
    });
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    ask(draft);
    setDraft('');
  }

  return <div className="page stack chat-page">
    <Heading eyebrow={t('አንድ ላይ እንማር', 'A LITTLE GUIDANCE')} title={t('ኦፓልን ይጠይቁ', 'Ask Opal')}
      description={t('ከተካተቱ ማስታወሻዎች የተመረጡ መልሶች።', 'Answers matched from notes bundled inside this prototype.')} />

    <div className="chat-thread" role="log" aria-live="polite" aria-label={t('የውይይት መልእክቶች', 'Conversation')}>
      {chat.map(message => message.from === 'user'
        ? <div key={message.id} className="bubble bubble-user">{message.text}</div>
        : <div key={message.id} className="bubble-row">
          <img className="chat-avatar" src={trinityMark} alt="" />
          <div className="bubble bubble-opal"><OpalReplyView reply={message.reply!} {...props} ask={ask} /></div>
        </div>)}
      <div ref={endRef} />
    </div>

    <div className="composer-wrap">
      <div className="chip-row" aria-label={t('የተጠቆሙ ጥያቄዎች', 'Suggested questions')}>
        {SUGGESTIONS.map(id => {
          const prompt = ASK_OPAL_PROMPTS.find(item => item.id === id)!;
          const label = lang === 'am' ? prompt.questionAm.split(' (')[0] : prompt.questionEn;
          return <button key={id} className="chip" onClick={() => ask(label, { kind: 'prompt', promptId: id })}>{label}</button>;
        })}
        <button className="chip" onClick={() => ask(t('ከባለሙያ ጋር መነጋገር እፈልጋለሁ', 'I would like to talk to a professional'), { kind: 'handover' })}>
          {t('ከባለሙያ ጋር መነጋገር', 'Talk to a professional')}
        </button>
      </div>
      <form className="composer" onSubmit={submit}>
        <input value={draft} onChange={event => setDraft(event.target.value)} maxLength={140} autoComplete="off"
          aria-label={t('ጥያቄዎን ይጻፉ', 'Type your question')}
          placeholder={t('ስለ ምግብ ወይም ንጽህና ይጠይቁ…', 'Ask about food, water, or hygiene…')} />
        <button type="submit" disabled={!draft.trim()} aria-label={t('ላክ', 'Ask')}><SendHorizontal size={19} /></button>
      </form>
      <p className="small-note centered">{t(
        'ስም፣ ስልክ ወይም የጤና ዝርዝር አይጻፉ። ጽሑፉ በዚህ ክፍለ ጊዜ ብቻ ይቆያል።',
        'Please don’t type names, phone numbers, or health details. Messages stay on this screen for this session only.')}</p>
    </div>
    {request && <button className="inline-care-link" onClick={() => navigate('care')}>
      <HeartHandshake size={23} /><span><strong>Requested — not yet confirmed</strong>
        <small>{t('የሙከራ ጥያቄውን በእንክብካቤ ገጽ ይመልከቱ', 'View your demo request in Care')}</small></span>
    </button>}
  </div>;
}

function OpalReplyView({ reply, lang, t, ask, request, setRequest, setChat, navigate, openLesson }: Props & { reply: OpalReply; ask: (text: string, reply?: OpalReply) => void }) {
  switch (reply.kind) {
    case 'welcome':
      return <>
        <strong>{t('ሰላም! እንዴት ልርዳዎት?', 'Selam! What shall we explore?')}</strong>
        <p>{t('ከታች ጥያቄ ይምረጡ ወይም ይጻፉ። ስለ ምግብ ደህንነት፣ ውሃ፣ እርግዝና፣ ጡት ማጥባት እና የህፃናት ምግብ መልስ አለኝ።',
          'Pick a question below or type your own. I can share notes on food safety, water, pregnancy, breastfeeding, and feeding young children.')}</p>
      </>;
    case 'prompt': {
      const prompt = ASK_OPAL_PROMPTS.find(item => item.id === reply.promptId)!;
      return <>
        <p>{lang === 'am' ? prompt.answerAm : prompt.answerEn}</p>
        <span className="source-note">{lang === 'am' ? prompt.sourceLabelAm : prompt.sourceLabelEn}</span>
        {prompt.actionType && <Button variant="secondary" onClick={() => prompt.actionType === 'open_meals' ? navigate('meals') : openLesson(prompt.sourceLessonId!)}>
          {prompt.actionType === 'open_meals' ? t('የምግብ ሀሳቦችን ይመልከቱ', 'Explore meal ideas') : t('ትምህርቱን ያንብቡ', 'Read the learning note')}<ArrowRight size={16} />
        </Button>}
      </>;
    }
    case 'lesson': {
      const lesson = LESSONS.find(item => item.id === reply.lessonId)!;
      return <>
        <p>{lang === 'am' ? lesson.summaryAm : lesson.summaryEn}</p>
        <p><strong>{t('ዋና ነጥብ፦ ', 'Key idea: ')}</strong>{lang === 'am' ? lesson.keyTakeawayAm : lesson.keyTakeawayEn}</p>
        <span className="source-note">{t('ምንጭ፦ የሙከራ ትምህርት — ', 'Bundled source: Prototype lesson — ')}{lang === 'am' ? lesson.titleAm : lesson.titleEn}</span>
        <Button variant="secondary" onClick={() => openLesson(lesson.id)}>{t('ትምህርቱን ያንብቡ', 'Read the learning note')}<ArrowRight size={16} /></Button>
      </>;
    }
    case 'warning':
      return <div className="warning-card" role="alert">
        <div className="warning-title"><Siren size={20} /><strong>{t('ይህ የጤና ተቋም ወይም ባለሙያ ሊያይው ይገባል', 'This may need a health facility or professional')}</strong></div>
        <p>{t(
          'የህመም ምልክት፣ ደም መፍሰስ፣ ከፍተኛ ትኩሳት፣ ትውከት፣ ተቅማጥ፣ የመተንፈስ ችግር፣ ራስን መሳት ወይም የመድኃኒት ጥያቄ ካለ፣ እባክዎ አሁኑኑ ወደ አቅራቢያዎ የጤና ተቋም ይሂዱ ወይም ብቁ የጤና ባለሙያ ያነጋግሩ።',
          'If you or a family member has warning signs such as bleeding, high fever, vomiting, diarrhoea, trouble breathing, fainting, or a question about medicine, please go to the nearest health facility or contact a qualified health professional now.')}</p>
        <p>{t('ኦፓል ምልክቶችን መገምገም ወይም መድኃኒት መምከር አይችልም። ይህ መተግበሪያ አይከታተልም፤ የሙከራ ጥያቄም ማንም ጋር አይደርስም።',
          'Opal cannot assess symptoms or recommend medicine. This prototype is not monitored, and a demo request reaches no one.')}</p>
      </div>;
    case 'handover':
      return <HandoverCard lang={lang} t={t} request={request} setRequest={setRequest} setChat={setChat} navigate={navigate} />;
    case 'handed': {
      const type = CONSULTATION_TYPES.find(item => item.id === request?.typeId);
      return request ? <>
        <span className="handed-status"><Check size={16} />Requested — not yet confirmed</span>
        {lang === 'am' && <p>ተጠይቋል — ገና አልተረጋገጠም</p>}
        <p>{lang === 'am' ? type?.labelAm.split(' (')[0] : type?.labelEn}</p>
        <p>{t('ምንም አልተላከም ወይም አልተያዘም። ማንም አያገኝዎትም።', 'Nothing was sent or booked. No one will contact you.')}</p>
        <Button variant="secondary" onClick={() => navigate('care')}>{t('በእንክብካቤ ገጽ ይመልከቱ', 'See it in Care')}<ArrowRight size={16} /></Button>
      </> : <p>{t('የሙከራ ጥያቄው ተወግዷል።', 'The demo request has been removed.')}</p>;
    }
    case 'fallback':
      return <>
        <p>{t('ለዚህ የተገመገመ መረጃ የለኝም። በዚህ መተግበሪያ ውስጥ ስላሉ ትምህርቶች መጠየቅ ይችላሉ።',
          'I don’t have reviewed information for that. I can only share the learning notes bundled in this prototype.')}</p>
        <div className="chip-row inline">
          {SUGGESTIONS.map(id => {
            const prompt = ASK_OPAL_PROMPTS.find(item => item.id === id)!;
            const label = lang === 'am' ? prompt.questionAm.split(' (')[0] : prompt.questionEn;
            return <button key={id} className="chip" onClick={() => ask(label, { kind: 'prompt', promptId: id })}>{label}</button>;
          })}
        </div>
      </>;
  }
}

function HandoverCard({ lang, t, request, setRequest, setChat, navigate }: Pick<Props, 'lang' | 't' | 'request' | 'setRequest' | 'setChat' | 'navigate'>) {
  const [type, setType] = useState(CONSULTATION_TYPES[0].id);
  const [consent, setConsent] = useState(false);
  const [passing, setPassing] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);

  if (request) {
    return <>
      <p>{t('የሙከራ ጥያቄ አስቀድሞ አለ።', 'You already have a demo request in this session.')}</p>
      <strong>Requested — not yet confirmed</strong>
      <Button variant="secondary" onClick={() => navigate('care')}>{t('በእንክብካቤ ገጽ ይመልከቱ', 'See it in Care')}<ArrowRight size={16} /></Button>
    </>;
  }

  function handOver() {
    setPassing(true);
    timer.current = setTimeout(() => {
      setRequest({ typeId: type, format: 'online' });
      setChat(previous => [...previous, { id: previous[previous.length - 1].id + 1, from: 'opal', reply: { kind: 'handed' } }]);
    }, 900);
  }

  return <>
    <p>{t('ከብቁ ባለሙያ ጋር ለመነጋገር የሙከራ ጥያቄ ማዘጋጀት እችላለሁ። ይህ ማስመሰል ብቻ ነው፤ ምንም አይላክም ወይም አይያዝም።',
      'I can pass you to the practice consultation request. It is a simulation only. Nothing is sent or booked, and no one is assigned.')}</p>
    <div className="choice-list">{CONSULTATION_TYPES.map(item => <Choice key={item.id} selected={type === item.id}
      title={lang === 'am' ? item.labelAm.split(' (')[0] : item.labelEn} onClick={() => setType(item.id)} />)}</div>
    <label className="check-label"><input type="checkbox" checked={consent} onChange={event => setConsent(event.target.checked)} />
      <span>{t('ይህ የሙከራ ጥያቄ ብቻ መሆኑን ተረድቻለሁ። ምንም አይላክም።', 'I understand this is only a simulation. Nothing is sent or booked.')}</span></label>
    <Button disabled={!consent || passing} onClick={handOver}>
      {passing ? <><Loader2 size={17} className="spin" />{t('በማስተላለፍ ላይ…', 'Passing you along…')}</> : <>{t('ወደ የሙከራ ጥያቄ አስተላልፍ', 'Hand over to demo request')}<ArrowRight size={17} /></>}
    </Button>
  </>;
}
