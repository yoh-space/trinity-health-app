export default function FieldIllustration({ small = false }: { small?: boolean }) {
  return <svg
    className={`field-illustration ${small ? 'small' : ''}`}
    viewBox="0 0 360 275"
    fill="none"
    aria-hidden="true"
  >
    <defs>
      <pattern id="basket-weave" width="12" height="12" patternUnits="userSpaceOnUse">
        <path d="M0 3H12M0 9H12M3 0V6M9 6V12" stroke="#0E7A33" strokeOpacity=".3" strokeWidth="1.2" />
      </pattern>
      <pattern id="grain-dots" width="8" height="8" patternUnits="userSpaceOnUse">
        <circle cx="2" cy="2" r=".8" fill="#0E7A33" fillOpacity=".22" />
      </pattern>
    </defs>
    <circle cx="185" cy="130" r="108" fill="#E1EDE2" />
    <circle cx="274" cy="62" r="29" fill="#7DC21E" fillOpacity=".75" />
    <circle cx="274" cy="62" r="36" stroke="#7DC21E" strokeOpacity=".35" strokeDasharray="2 5" />
    <path d="M40 181C86 160 96 169 138 149C195 123 243 144 321 122V214H40Z" fill="#D3E6D6" />
    <path d="M45 206C111 164 170 178 218 162C264 146 301 163 328 154" stroke="#7FB58A" strokeOpacity=".55" />
    <path d="M63 215C130 183 216 209 308 179" stroke="#7FB58A" strokeOpacity=".55" />
    <ellipse cx="181" cy="245" rx="127" ry="9" fill="#BBD3BF" fillOpacity=".5" />
    <path d="M61 220L67 147M66 167C47 165 42 151 43 142C59 143 67 152 66 167ZM65 186C84 182 91 168 89 158C73 160 65 172 65 186Z" fill="#5FA06B" />
    <path d="M65 169C62 151 70 137 81 132C87 149 78 163 65 169Z" fill="#3E7F52" />
    <path d="M293 228V115M293 149C274 143 270 129 273 117C286 120 294 135 293 149ZM294 173C311 169 319 156 318 145C303 146 294 158 294 173Z" fill="#3E7F52" />
    <path d="M293 124C281 109 283 96 291 87C302 98 303 111 293 124Z" fill="#5FA06B" />
    <path d="M291 201C271 196 265 181 267 170C284 173 291 187 291 201Z" fill="#5FA06B" />
    <path d="M95 207H259L245 241H109Z" fill="#7DC21E" stroke="#0E7A33" strokeWidth="1.5" />
    <path d="M95 207H259L245 241H109Z" fill="url(#basket-weave)" />
    <ellipse cx="177" cy="207" rx="83" ry="21" fill="#C5E58F" stroke="#0E7A33" strokeWidth="1.5" />
    <ellipse cx="177" cy="203" rx="74" ry="19" fill="#8FC98F" />
    <ellipse cx="177" cy="203" rx="74" ry="19" fill="url(#grain-dots)" />
    <path d="M110 208C132 218 211 218 242 207" stroke="#EAF4E8" strokeDasharray="2 3" />
    <path d="M147 183C140 171 143 156 151 153H221C231 162 229 178 218 188C202 198 163 197 147 183Z" fill="#1E8E43" stroke="#0A5C26" strokeWidth="1.7" />
    <path d="M153 177C157 186 164 188 175 190" stroke="#6FBF73" strokeWidth="3" strokeLinecap="round" />
    <path d="M145 159L137 158C128 158 126 170 139 174L145 175M226 159L234 158C243 158 245 170 232 174L226 175" stroke="#0A5C26" strokeWidth="4" />
    <ellipse cx="186" cy="153" rx="37" ry="8" fill="#0A5C26" stroke="#0A5C26" strokeWidth="1.5" />
    <ellipse cx="186" cy="152" rx="31" ry="5" fill="#7DC21E" />
    <path d="M168 133C160 125 178 119 171 108M186 128C179 119 195 111 187 101M203 134C196 126 209 122 205 114" stroke="#0E7A33" strokeOpacity=".45" strokeWidth="1.7" strokeLinecap="round" />
    <path d="M108 197C103 183 106 172 114 167C119 176 120 185 116 196M119 198C120 183 128 177 138 179C137 190 130 197 119 198Z" fill="#3E7F52" />
    <ellipse cx="231" cy="202" rx="12" ry="5" fill="#5FA06B" />
    <ellipse cx="215" cy="207" rx="9" ry="4" fill="#7DC21E" />
    <path d="M104 136L109 130L114 136L109 142Z" fill="#7DC21E" />
    <path d="M241 102L245 97L249 102L245 107Z" fill="#0E7A33" fillOpacity=".65" />
    <path d="M121 69L125 64L129 69L125 74Z" fill="#0E7A33" fillOpacity=".4" />
    <path d="M54 98C58 93 63 93 67 98M71 82C75 77 80 77 84 82" stroke="#6B8F77" strokeWidth="1.3" strokeLinecap="round" />
    <path d="M140 239L145 235L150 239L145 243ZM201 239L206 235L211 239L206 243Z" fill="#0E7A33" />
    <path d="M157 239H194" stroke="#0E7A33" strokeDasharray="2 3" />
  </svg>;
}
