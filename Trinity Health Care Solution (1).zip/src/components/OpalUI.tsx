import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { ArrowRight, Bookmark, Check, Clock3, Info, Leaf } from 'lucide-react';
import type { Language, Lesson } from '../data/opalData';
import { LessonCueIllustration } from './WovenMotifs';

export const LESSON_PHOTOS: Record<string, string> = {
  'lesson-food-safety-home': 'https://images.unsplash.com/photo-1590610994353-7b0e7546e681?auto=format&fit=crop&w=320&h=320&q=75',
  'lesson-pregnancy-plate': 'https://images.unsplash.com/photo-1539735776517-befcae86494d?auto=format&fit=crop&w=320&h=320&q=75',
  'lesson-child-complementary': 'https://images.unsplash.com/photo-1544829832-c8047d6b9d89?auto=format&fit=crop&w=320&h=320&q=75',
  'lesson-breastfeeding-hydration': 'https://images.unsplash.com/photo-1487546331507-fcf8a5d27ab3?auto=format&fit=crop&w=320&h=320&q=75',
  'lesson-clean-water-hygiene': 'https://images.unsplash.com/photo-1602904761432-f9ad96133982?auto=format&fit=crop&w=320&h=320&q=75',
};

export type Translate = (am: string, en: string) => string;

export function Button({
  children,
  variant = 'primary',
  className = '',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'quiet' | 'danger';
}) {
  return <button className={`button button-${variant} ${className}`} {...props}>{children}</button>;
}

export function IconButton({
  label,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return <button className="icon-button" aria-label={label} title={label} {...props}>{children}</button>;
}

export function Heading({ eyebrow, title, description }: {
  eyebrow?: string;
  title: string;
  description?: string;
}) {
  return <div className="page-heading">
    {eyebrow && <p className="eyebrow">{eyebrow}</p>}
    <h1 className="editorial">{title}</h1>
    {description && <p className="muted">{description}</p>}
  </div>;
}

export function SectionHeading({ title, action, onAction }: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  return <div className="section-heading">
    <h2 className="editorial">{title}</h2>
    {action && <button className="text-link" onClick={onAction}>{action}<ArrowRight size={15} /></button>}
  </div>;
}

export function Notice({ children, kind = 'cream' }: {
  children: ReactNode;
  kind?: 'cream' | 'green' | 'gold';
}) {
  return <div className={`notice notice-${kind}`}><Info size={17} aria-hidden="true" /><div>{children}</div></div>;
}

export function Choice({ selected, title, description, icon, onClick }: {
  selected: boolean;
  title: string;
  description?: string;
  icon?: ReactNode;
  onClick: () => void;
}) {
  return <button className={`choice ${selected ? 'selected' : ''}`} aria-pressed={selected} onClick={onClick}>
    {icon && <span className="choice-icon">{icon}</span>}
    <span className="choice-copy"><strong>{title}</strong>{description && <span>{description}</span>}</span>
    <span className="choice-check">{selected && <Check size={14} />}</span>
  </button>;
}

export function LessonCard({ lesson, lang, saved, onOpen, onSave }: {
  lesson: Lesson;
  lang: Language;
  saved: boolean;
  onOpen: () => void;
  onSave: () => void;
}) {
  return <article className="lesson-card">
    <button className="lesson-card-open" onClick={onOpen}>
      {LESSON_PHOTOS[lesson.id] ? <img className="lesson-photo" src={LESSON_PHOTOS[lesson.id]} alt="" loading="lazy" />
        : <LessonCueIllustration type={lesson.sections[0].cueIcon} />}
      <span className="lesson-card-copy">
        <span className="eyebrow">{lang === 'am' ? lesson.topicLabelAm.split(' · ')[0] : lesson.topicLabelEn}</span>
        <strong>{lang === 'am' ? lesson.titleAm : lesson.titleEn}</strong>
        <span className="meta"><Clock3 size={12} />{lang === 'am' ? lesson.readTimeAm : lesson.readTimeEn}</span>
      </span>
    </button>
    <IconButton label={lang === 'am' ? (saved ? 'ከተቀመጡት አስወግድ' : 'ትምህርት አስቀምጥ') : (saved ? 'Unsave lesson' : 'Save lesson')} onClick={onSave} aria-pressed={saved}>
      <Bookmark size={19} fill={saved ? 'currentColor' : 'none'} />
    </IconButton>
  </article>;
}

export function EmptyState({ title, description, action, onAction }: {
  title: string;
  description: string;
  action?: string;
  onAction?: () => void;
}) {
  return <div className="empty-state">
    <span className="empty-icon"><Leaf size={28} strokeWidth={1.4} /></span>
    <h2 className="editorial">{title}</h2><p className="muted">{description}</p>
    {action && <Button variant="secondary" onClick={onAction}>{action}<ArrowRight size={16} /></Button>}
  </div>;
}

export default Heading;
