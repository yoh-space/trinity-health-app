import React from 'react';
import { Language } from '../data/opalData';

/**
 * Opal Care Brand Symbol:
 * Inspired by a sprouting grain/seed and dual leaf cradled inside a woven circle.
 */
export const OpalEmblem: React.FC<{ size?: number; className?: string }> = ({
  size = 48,
  className = '',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* Warm cream background disc */}
    <circle cx="32" cy="32" r="30" fill="#EAF4E8" stroke="#0E7A33" strokeWidth="2" />
    {/* Woven outer ring stitches */}
    <circle
      cx="32"
      cy="32"
      r="25.5"
      stroke="#7DC21E"
      strokeWidth="1.75"
      strokeDasharray="4 3"
    />
    {/* Four woven compass diamonds */}
    <path d="M32 3L34.5 6.5L32 10L29.5 6.5L32 3Z" fill="#0E7A33" />
    <path d="M32 54L34.5 57.5L32 61L29.5 57.5L32 54Z" fill="#0E7A33" />
    <path d="M3 32L6.5 29.5L10 32L6.5 34.5L3 32Z" fill="#7DC21E" />
    <path d="M54 32L57.5 29.5L61 32L57.5 34.5L54 32Z" fill="#7DC21E" />

    {/* Left nurturing leaf */}
    <path
      d="M31 44C21 43 16 34 18 23C25 23 31 29 31 40"
      fill="#2F8F4E"
      fillOpacity="0.16"
      stroke="#2F8F4E"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* Right nurturing leaf */}
    <path
      d="M33 44C43 43 48 34 46 23C39 23 33 29 33 40"
      fill="#2F8F4E"
      fillOpacity="0.16"
      stroke="#2F8F4E"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* Central golden seed / grain */}
    <path
      d="M32 15C36.5 20.5 37.5 29 32 37C26.5 29 27.5 20.5 32 15Z"
      fill="#7DC21E"
      stroke="#0E7A33"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    {/* Grounded clay root line */}
    <path
      d="M24 47.5H40"
      stroke="#0E7A33"
      strokeWidth="2.2"
      strokeLinecap="round"
    />
  </svg>
);

/**
 * Subtle Ethiopian Tibeb woven divider:
 * Used strictly as a small horizontal border or section divider, never behind essential text.
 */
export const TibebBorder: React.FC<{ variant?: 'clay' | 'gold' | 'subtle'; className?: string }> = ({
  variant = 'clay',
  className = '',
}) => {
  const primary = variant === 'gold' ? '#7DC21E' : '#0E7A33';
  const secondary = variant === 'gold' ? '#0E7A33' : '#7DC21E';
  const tertiary = '#2F8F4E';

  return (
    <div
      className={`w-full overflow-hidden select-none pointer-events-none ${className}`}
      aria-hidden="true"
    >
      <svg
        width="100%"
        height="7"
        viewBox="0 0 360 7"
        preserveAspectRatio="none"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <line x1="0" y1="0.75" x2="360" y2="0.75" stroke="#D5E6D3" strokeWidth="1" />
        {Array.from({ length: 18 }).map((_, idx) => {
          const x = idx * 20;
          return (
            <g key={idx}>
              <polygon
                points={`${x + 4},3.5 ${x + 8},1.2 ${x + 12},3.5 ${x + 8},5.8`}
                fill={idx % 2 === 0 ? primary : secondary}
                fillOpacity={variant === 'subtle' ? '0.65' : '0.88'}
              />
              <circle
                cx={x + 18}
                cy="3.5"
                r="1.2"
                fill={tertiary}
                fillOpacity="0.7"
              />
            </g>
          );
        })}
        <line x1="0" y1="6.25" x2="360" y2="6.25" stroke="#D5E6D3" strokeWidth="1" />
      </svg>
    </div>
  );
};

/**
 * Calm, visible offline status pill
 */
export const OfflineStatusBanner: React.FC<{ lang: Language; compact?: boolean }> = ({
  lang,
  compact = false,
}) => (
  <div
    className={`inline-flex items-center gap-2 rounded-full border border-[#2F8F4E]/30 bg-[#E8F5EC] text-[#14532B] ${
      compact ? 'px-2.5 py-1 text-xs' : 'px-3.5 py-1.5 text-xs font-medium'
    }`}
  >
    <span className="h-2 w-2 rounded-full bg-[#2F8F4E] shrink-0" />
    <span>
      {lang === 'am'
        ? 'ትምህርቶች ያለ ኢንተርኔት ይገኛሉ · Lessons are available offline.'
        : 'Lessons are available offline.'}
    </span>
  </div>
);

/**
 * Prototype clinical review tag
 */
export const PrototypeReviewTag: React.FC<{ lang: Language; variant?: 'card' | 'detail' }> = ({
  lang,
  variant = 'card',
}) => {
  if (variant === 'detail') {
    return (
      <div className="rounded-xl border border-[#7DC21E]/55 bg-[#F1F8E4] px-3.5 py-3 text-xs leading-relaxed text-[#3B5A0B]">
        <div className="font-semibold text-[#14221A] flex items-center gap-1.5 mb-0.5">
          <span className="inline-block h-2 w-2 rounded-full bg-[#7DC21E]" />
          <span>
            {lang === 'am'
              ? 'የባለሙያ ግምገማ በመጠባበቅ ላይ · Qualified Ethiopian clinical review pending'
              : 'Qualified Ethiopian clinical review pending'}
          </span>
        </div>
        <p className="text-[#4B5C51]">
          {lang === 'am'
            ? 'ይህ የሙከራ ትምህርት (Prototype learning) ለዲዛይን ሙከራ የተዘጋጀ ሲሆን፣ ለህዝብ ከመሰራጨቱ በፊት በኢትዮጵያ ብቁ የጤና እና የአመጋገብ ባለሙያዎች መገምገም አለበት።'
            : 'Prototype learning · clinical review pending. This sample note is for prototype evaluation and requires formal review by qualified Ethiopian nutrition clinicians before release.'}
        </p>
      </div>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 rounded-md bg-[#EEF6DF] border border-[#7DC21E]/45 px-2 py-0.5 text-[11px] font-medium text-[#3B5A0B]">
      <span className="h-1.5 w-1.5 rounded-full bg-[#7DC21E] shrink-0" />
      <span>
        {lang === 'am'
          ? 'የሙከራ ትምህርት · Prototype learning · clinical review pending'
          : 'Prototype learning · clinical review pending'}
      </span>
    </span>
  );
};

/**
 * Low-literacy friendly illustrative cue icons for Lesson Detail sections
 */
export const LessonCueIllustration: React.FC<{
  type: 'pot' | 'hands' | 'grain' | 'water' | 'spoon' | 'leaf';
}> = ({ type }) => {
  return (
    <div
      className="h-11 w-11 rounded-xl bg-[#EAF4E8] border border-[#D5E6D3] flex items-center justify-center shrink-0 text-[#0E7A33]"
      aria-hidden="true"
    >
      {type === 'pot' && (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path
            d="M4 11H20V16C20 18.2091 18.2091 20 16 20H8C5.79086 20 4 18.2091 4 16V11Z"
            fill="#7DC21E"
            fillOpacity="0.25"
            stroke="#0E7A33"
            strokeWidth="1.8"
          />
          <path d="M2 11H22" stroke="#0E7A33" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M9 8C9 6.5 10.5 6.5 10.5 5" stroke="#2F8F4E" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M14 8C14 6.5 15.5 6.5 15.5 5" stroke="#2F8F4E" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      )}
      {type === 'hands' && (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="7" r="2.5" fill="#2F8F4E" fillOpacity="0.25" stroke="#2F8F4E" strokeWidth="1.6" />
          <path
            d="M6 16C7.5 13.5 10 13 12 13C14 13 16.5 13.5 18 16"
            stroke="#0E7A33"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          <path
            d="M5 19.5H19"
            stroke="#7DC21E"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      )}
      {type === 'grain' && (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M12 4V20" stroke="#0E7A33" strokeWidth="1.8" strokeLinecap="round" />
          <ellipse cx="9" cy="8" rx="2.5" ry="1.6" transform="rotate(-25 9 8)" fill="#7DC21E" stroke="#0E7A33" strokeWidth="1.4" />
          <ellipse cx="15" cy="10" rx="2.5" ry="1.6" transform="rotate(25 15 10)" fill="#7DC21E" stroke="#0E7A33" strokeWidth="1.4" />
          <ellipse cx="9" cy="14" rx="2.5" ry="1.6" transform="rotate(-25 9 14)" fill="#7DC21E" stroke="#0E7A33" strokeWidth="1.4" />
          <ellipse cx="15" cy="16" rx="2.5" ry="1.6" transform="rotate(25 15 16)" fill="#7DC21E" stroke="#0E7A33" strokeWidth="1.4" />
        </svg>
      )}
      {type === 'water' && (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path
            d="M12 4C12 4 6.5 10.5 6.5 14.5C6.5 17.5376 8.96243 20 12 20C15.0376 20 17.5 17.5376 17.5 14.5C17.5 10.5 12 4 12 4Z"
            fill="#2F8F4E"
            fillOpacity="0.2"
            stroke="#2F8F4E"
            strokeWidth="1.8"
          />
          <path d="M9.5 15C10 16.2 11.2 17 12.5 17" stroke="#0E7A33" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      )}
      {type === 'spoon' && (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <ellipse cx="9" cy="9" rx="4.5" ry="3.2" fill="#7DC21E" fillOpacity="0.3" stroke="#0E7A33" strokeWidth="1.8" />
          <path d="M12.5 11.2L19 17.8" stroke="#0E7A33" strokeWidth="2" strokeLinecap="round" />
        </svg>
      )}
      {type === 'leaf' && (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path
            d="M18 5C10 5 6 9.5 6 17C13.5 17 18 13 18 5Z"
            fill="#2F8F4E"
            fillOpacity="0.22"
            stroke="#2F8F4E"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
          <path d="M6 17L14 9" stroke="#0E7A33" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      )}
    </div>
  );
};
