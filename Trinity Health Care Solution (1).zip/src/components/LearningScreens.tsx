import { useState } from 'react';
import { ArrowRight, Bookmark, Check, Clock3, Leaf, MessageCircle, Search, ShieldCheck, Sprout } from 'lucide-react';
import { LESSONS, TOPICS, type CareStage, type Language, type Lesson, type ScreenId, type TopicId } from '../data/opalData';
import { LESSON_PHOTOS, Button, EmptyState, Heading, LessonCard, Notice, SectionHeading, type Translate } from './OpalUI';
import { LessonCueIllustration, TibebBorder } from './WovenMotifs';
import { CONDITIONS, GOALS, labelOf, type Profile } from '../lib/profile';
import FieldIllustration from './FieldIllustration';

type CommonProps = { lang: Language; t: Translate; openLesson: (id: string) => void };

export function HomeScreen({ lang, t, stage, profile, editProfile, navigate, openLesson, saved, toggleSave }: CommonProps & {
  stage: CareStage;
  profile: Profile | null;
  editProfile: () => void;
  navigate: (screen: ScreenId) => void;
  saved: string[];
  toggleSave: (id: string) => void;
}) {
  const featured = LESSONS[0];
  const personalized = stage !== 'none' && stage !== 'prefer_not_to_say';
  const recommended = [...LESSONS].filter(lesson => lesson.id !== featured.id).sort((a, b) =>
    Number(b.relevantStages.includes(stage)) - Number(a.relevantStages.includes(stage))).slice(0, 2);
  return <div className="page home-page stack">
    <div className="home-greeting">
      <div><p className="eyebrow">{t('ለዕለት ተዕለት እንክብካቤ', 'YOUR EVERYDAY FIELD NOTES')}</p>
        <h1 className="editorial">{t('ሰላም፣ እንኳን ደህና መጡ።', 'Selam, make yourself at home.')}</h1>
        <p className="muted">{t('ትንሽ እውቀት፣ ብዙ እንክብካቤ።', 'A little learning. A lot of care.')}</p></div>
      <span className="greeting-leaf"><Sprout size={28} strokeWidth={1.4} /></span>
    </div>
    {profile && (profile.conditions.length > 0 || profile.goals.length > 0) && <section className="plan-card" aria-label={t('የእርስዎ እቅድ', 'Your plan')}>
      <div><p className="eyebrow">{t('የእርስዎ እቅድ', 'YOUR PLAN')}</p>
        <div className="plan-chips">{[...profile.conditions.map(id => labelOf(CONDITIONS, id, lang)), ...profile.goals.slice(0, 2).map(id => labelOf(GOALS, id, lang))].map(label => <span key={label}>{label}</span>)}</div></div>
      <button onClick={editProfile}>{t('ቀይር', 'Edit')}</button>
    </section>}
    <section className="featured-note">
      <div className="featured-topline"><span className="eyebrow">{t('የዛሬ ትንሽ ትምህርት', 'TODAY’S LITTLE LESSON')}</span><span className="note-number">01 / 05</span></div>
      <div className="featured-body">
        <div><span className="pill light"><ShieldCheck size={12} />{t('የምግብ ደህንነት', 'Food safety')}</span>
          <h2 className="editorial">{t('ጤናማ ምግብ፣ ከትንሽ ልምዶች ይጀምራል።', 'Small habits. Safer family meals.')}</h2></div>
        <FieldIllustration small />
      </div>
      <p>{t('ንጹህ እጅ፣ በደንብ የበሰለ ምግብ፣ የተከደነ ዕቃ። አንድ ላይ እንማር።', 'Clean hands, a well-cooked pot, a covered dish. Let’s start with the everyday things.')}</p>
      <div className="featured-footer"><button onClick={() => openLesson(featured.id)}>{t('አብረን እንማር', 'Open today’s note')}<ArrowRight size={16} /></button><span><Clock3 size={13} />{t('3 ደቂቃ', '3 min')}</span></div>
      <TibebBorder variant="gold" />
    </section>
    <div className="quick-actions">
      <button className="quick-action meals" onClick={() => navigate('meals')}><img className="quick-photo" src="https://images.unsplash.com/photo-1746716447103-e1618bbd0669?auto=format&fit=crop&w=420&h=240&q=75" alt="" loading="lazy" />
        <strong>{t('ምን እናብስል?', 'What’s in your kitchen?')}</strong><span>{t('ቀላል የምግብ ሀሳቦች', 'Find a little meal inspiration')}<ArrowRight size={14} /></span></button>
      <button className="quick-action saved" onClick={() => navigate('saved')}><span className="quick-icon"><Bookmark size={23} strokeWidth={1.5} /></span>
        <strong>{t('የእኔ ማስታወሻዎች', 'Your saved notes')}</strong><span>{saved.length ? t(`${saved.length} ትምህርቶች ተቀምጠዋል`, `${saved.length} notes tucked away`) : t('ለሌላ ጊዜ ያስቀምጡ', 'Keep a good thought close')}<ArrowRight size={14} /></span></button>
    </div>
    <section>
      <SectionHeading title={personalized ? t('ለእርስዎ የተመረጠ', 'A few notes for you') : t('አንድ ላይ እናድግ', 'Grow a little every day')}
        action={t('ሁሉንም እይ', 'View all')} onAction={() => navigate('learn')} />
      {personalized && <p className="small-note recommendation-note">{t('በክፍለ ጊዜ ምርጫዎ መሠረት የተደረደረ። ሁሉም ትምህርቶች ሁልጊዜ ይገኛሉ።', 'Reordered by your session choice. All lessons remain available.')}</p>}
      <div className="lesson-list">{recommended.map(lesson => <LessonCard key={lesson.id} lesson={lesson} lang={lang} saved={saved.includes(lesson.id)}
        onOpen={() => openLesson(lesson.id)} onSave={() => toggleSave(lesson.id)} />)}</div>
    </section>
    <button className="ask-strip" onClick={() => navigate('ask-opal')}><span className="ask-symbol"><MessageCircle size={22} strokeWidth={1.5} /></span>
      <span><strong>{t('ጥያቄ አለዎት? ኦፓልን ይጠይቁ።', 'A little curious? Ask Opal.')}</strong><small>{t('ከአካባቢ ማስታወሻዎች አብረን እንማር።', 'Explore answers from our bundled notes.')}</small></span><ArrowRight size={18} /></button>
    <div className="home-signoff"><Leaf size={13} /><span>{t('በእንክብካቤ የተሰራ፣ ለቤተሰብ።', 'Rooted in care. Made for family.')}</span></div>
  </div>;
}

export function LearnScreen({ lang, t, openLesson, saved, toggleSave }: CommonProps & {
  saved: string[];
  toggleSave: (id: string) => void;
}) {
  const [query, setQuery] = useState('');
  const [topic, setTopic] = useState<TopicId>('all');
  const lessons = LESSONS.filter(lesson => (topic === 'all' || lesson.topic === topic)
    && `${lesson.titleAm} ${lesson.titleEn} ${lesson.summaryAm} ${lesson.summaryEn} ${lesson.topicLabelAm} ${lesson.topicLabelEn}`.toLocaleLowerCase().includes(query.toLocaleLowerCase().trim()));
  return <div className="page stack">
    <Heading eyebrow={t('አንድ ማስታወሻ በአንድ ጊዜ', 'ONE GOOD NOTE AT A TIME')} title={t('አብረን እንማር', 'Good things to know')}
      description={t('ለዕለት ተዕለት ሕይወት ቀላል የአመጋገብ ማስታወሻዎች።', 'Simple, thoughtful nutrition notes for everyday family life.')} />
    <label className="search-field"><Search size={19} /><span className="sr-only">{t('ትምህርቶችን ፈልግ', 'Search bundled lessons')}</span>
      <input value={query} onChange={event => setQuery(event.target.value)} type="search" autoComplete="off" maxLength={100}
        placeholder={t('ስለ ምግብ፣ ውሃ ወይም እንክብካቤ ፈልግ…', 'Find a topic, food, or everyday habit…')} /></label>
    <div className="topic-chips no-scrollbar" role="group" aria-label={t('የትምህርት ርዕሶች', 'Lesson topics')}>
      {TOPICS.map(item => <button key={item.id} className={`chip ${topic === item.id ? 'active' : ''}`} aria-pressed={topic === item.id}
        onClick={() => setTopic(item.id)}>{lang === 'am' ? item.labelAm.split(' (')[0] : item.labelEn}</button>)}
    </div>
    <div className="library-caption"><span className="eyebrow">{t('ከማስታወሻ ደብተራችን', 'FROM OUR FIELD NOTEBOOK')}</span><span>{lessons.length} {t('ትምህርቶች', 'notes')}</span></div>
    {lessons.length ? <div className="lesson-list library-list">{lessons.map(lesson => <LessonCard key={lesson.id} lesson={lesson} lang={lang}
      saved={saved.includes(lesson.id)} onOpen={() => openLesson(lesson.id)} onSave={() => toggleSave(lesson.id)} />)}</div>
      : <EmptyState title={t('እዚህ ምንም አልተገኘም', 'No notes here just yet')}
        description={t('ሌላ ቃል ወይም ርዕስ ይሞክሩ።', 'Try another word or browse all our bundled topics.')}
        action={t('ሁሉንም ትምህርቶች አሳይ', 'Show all notes')} onAction={() => { setQuery(''); setTopic('all'); }} />}
    <Notice kind="green"><BookMarkText t={t} /></Notice>
  </div>;
}

function BookMarkText({ t }: { t: Translate }) {
  return <>{t('መመዝገብ ሳያስፈልግ ሁሉንም ትምህርቶች ያንብቡ። ማስቀመጫውን በመንካት ወደ ስብስብዎ ያክሉ።', 'No sign-up, no rush. Every lesson is open to you. Tap a bookmark to keep one close.')}</>;
}

export function LessonDetailScreen({ lesson, lang, t, saved, toggleSave, completed, onComplete }: {
  lesson: Lesson;
  lang: Language;
  t: Translate;
  saved: boolean;
  toggleSave: () => void;
  completed: boolean;
  onComplete: () => void;
}) {
  return <article className="page lesson-detail stack">
    <Heading eyebrow={lang === 'am' ? lesson.topicLabelAm.split(' · ')[0] : lesson.topicLabelEn}
      title={lang === 'am' ? lesson.titleAm : lesson.titleEn} />
    <div className="detail-meta"><span><Clock3 size={14} />{lang === 'am' ? lesson.readTimeAm : lesson.readTimeEn}</span>
      <button className={`text-link ${saved ? 'is-saved' : ''}`} onClick={toggleSave} aria-pressed={saved}>
        <Bookmark size={16} fill={saved ? 'currentColor' : 'none'} />{saved ? t('ተቀምጧል', 'Saved') : t('ለሌላ ጊዜ አስቀምጥ', 'Save for later')}</button></div>
    {LESSON_PHOTOS[lesson.id] ? <div className="lesson-cover lesson-cover-photo"><img src={LESSON_PHOTOS[lesson.id].replace('w=320&h=320', 'w=900&h=450')} alt="" /></div>
      : <div className="lesson-cover"><FieldIllustration /></div>}
    <p className="lesson-intro">{lang === 'am' ? lesson.summaryAm : lesson.summaryEn}</p>
    <TibebBorder variant="subtle" />
    <div className="lesson-sections">{lesson.sections.map((section, index) => <section key={section.headingEn}>
      <div className="lesson-section-heading"><LessonCueIllustration type={section.cueIcon} />
        <h2 className="editorial">{(lang === 'am' ? section.headingAm : section.headingEn).replace(/^\d+\.\s*/, '')}</h2>
        <span className="section-number">0{index + 1}</span></div>
      <p>{lang === 'am' ? section.bodyAm : section.bodyEn}</p>
    </section>)}</div>
    <div className="takeaway"><Sprout size={23} strokeWidth={1.5} /><p>{lang === 'am' ? lesson.keyTakeawayAm : lesson.keyTakeawayEn}</p></div>
    <p className="small-note">{t('ምንጭ፦ ከዚህ መተግበሪያ ጋር የተካተተ የሙከራ ማስታወሻ። የታተመ ክሊኒካዊ መመሪያ አይደለም።', 'Source: Trinity Health Solution bundled prototype note. This is not a published clinical guideline or individualized nutrition plan.')}</p>
    <Button variant={completed ? 'secondary' : 'primary'} onClick={onComplete} disabled={completed}><Check size={18} />
      {completed ? t('ለዛሬ ተነብቧል', 'A little learning, done') : t('እንደተነበበ ምልክት አድርግ', 'Mark this note as read')}</Button>
    <p className="small-note centered">{t('የንባብ ምልክት ለዚህ ክፍለ ጊዜ ብቻ ይቆያል።', 'Reading progress lasts for this session only.')}</p>
  </article>;
}

export default HomeScreen;
