import { useState } from 'react';
import { ArrowRight, CalendarClock, Check, Clock3, Laptop, MapPin, Plus, Share2, Siren, UserPlus } from 'lucide-react';
import { CONSULTATION_TYPES, LESSONS } from '../data/opalData';
import { STAFF_STATUS, type QueueItem, type StaffMember } from '../data/staffData';

interface Common {
  queue: QueueItem[];
  openRequest: (id: string) => void;
  notify: (message: string) => void;
}

const typeLabel = (id: string) => CONSULTATION_TYPES.find(item => item.id === id)?.labelEn ?? id;
const OPEN: QueueItem['status'][] = ['new', 'in_review', 'assigned', 'scheduled'];

function Kpis({ items }: { items: [number, string][] }) {
  return <div className="kpi-row" style={{ gridTemplateColumns: `repeat(${items.length}, 1fr)` }}>
    {items.map(([value, label]) => <div className="kpi" key={label}><strong>{value}</strong><span>{label}</span></div>)}
  </div>;
}

function MiniRequest({ item, openRequest }: { item: QueueItem; openRequest: (id: string) => void }) {
  return <button className="staff-card" onClick={() => openRequest(item.id)}>
    <div className="staff-card-top"><strong>{item.id}</strong><span className={`staff-pill tone-${STAFF_STATUS[item.status].tone}`}>{STAFF_STATUS[item.status].label}</span></div>
    <span className="staff-card-title">{typeLabel(item.typeId)}</span>
    <div className="staff-card-meta">
      <span>{item.format === 'online' ? <Laptop size={13} /> : <MapPin size={13} />}{item.format === 'online' ? 'Online' : 'In person'}</span>
      <span><Clock3 size={13} />{item.slot ?? item.received}</span>
    </div>
  </button>;
}

function NextSession({ item, openRequest, label }: { item?: QueueItem; openRequest: (id: string) => void; label: string }) {
  if (!item) return <div className="next-session empty"><CalendarClock size={22} /><div><strong>No session booked</strong><span>Scheduled sessions will appear here.</span></div></div>;
  return <button className="next-session" onClick={() => openRequest(item.id)}>
    <CalendarClock size={22} />
    <div><small>{label}</small><strong>{item.slot}</strong><span>{typeLabel(item.typeId)} · {item.format === 'online' ? 'Online' : 'In person'}</span></div>
    <ArrowRight size={18} />
  </button>;
}

export function CounselorHome({ queue, me, openRequest, notify, goRequests }: Common & { me: string; goRequests: () => void }) {
  const mine = queue.filter(item => item.assignee === me && OPEN.includes(item.status));
  const next = mine.find(item => item.status === 'scheduled');
  const firstLook = queue.filter(item => item.status === 'new' || item.status === 'in_review').slice(0, 3);
  const [shared, setShared] = useState<string[]>([]);
  return <div className="page stack">
    <div className="page-heading"><p className="eyebrow">COUNSELOR DESK</p><h1 className="editorial">Good day, {me.split(' ')[0]}.</h1>
      <p className="muted">Guide families toward everyday nutrition habits.</p></div>
    <Kpis items={[[mine.length, 'My open cases'], [mine.filter(item => item.status === 'scheduled').length, 'Sessions booked'], [firstLook.length, 'Need a look']]} />
    <NextSession item={next} openRequest={openRequest} label="NEXT SESSION" />
    <section>
      <div className="section-row"><h2 className="editorial section-title">Needs a first look</h2><button className="text-link" onClick={goRequests}>All requests<ArrowRight size={14} /></button></div>
      {firstLook.length ? <div className="staff-list">{firstLook.map(item => <MiniRequest key={item.id} item={item} openRequest={openRequest} />)}</div>
        : <p className="muted">All caught up. New requests will appear here.</p>}
    </section>
    <section>
      <div className="section-row"><h2 className="editorial section-title">Education toolkit</h2></div>
      <p className="muted tight">Pick a note to prepare for a session. Sharing is simulated.</p>
      <div className="toolkit no-scrollbar">{LESSONS.map(lesson => {
        const done = shared.includes(lesson.id);
        return <article key={lesson.id} className="toolkit-card">
          <span className="eyebrow">{lesson.topicLabelEn}</span><strong>{lesson.titleEn}</strong>
          <button className={`chip ${done ? 'active' : ''}`} onClick={() => { setShared(previous => done ? previous : [...previous, lesson.id]); if (!done) notify('Marked as ready to share. Nothing was sent.'); }}>
            {done ? <><Check size={14} />Ready</> : <><Share2 size={14} />Prepare</>}</button>
        </article>;
      })}</div>
    </section>
  </div>;
}

const FOCUS = [
  { id: 'f1', title: 'Balanced plate basics', tip: 'Half vegetables, a quarter protein, a quarter whole grains.' },
  { id: 'f2', title: 'Lower-salt cooking', tip: 'Season with herbs, onion, garlic, and spices instead of extra salt.' },
  { id: 'f3', title: 'Everyday movement', tip: 'Short walks after meals fit into most family routines.' },
  { id: 'f4', title: 'Stress and sleep', tip: 'Regular meals and a calm evening routine support wellbeing.' },
];

export function ClinicianHome({ queue, me, openRequest, goRequests }: Common & { me: string; goRequests: () => void }) {
  const mine = queue.filter(item => item.assignee === me && OPEN.includes(item.status));
  const upcoming = mine.filter(item => item.status === 'scheduled' || item.status === 'assigned');
  const [prepared, setPrepared] = useState<string[]>(['f2']);
  const [checkins, setCheckins] = useState([{ id: 'c1', label: 'Wellbeing check-in · Family A', done: false }, { id: 'c2', label: 'Lifestyle follow-up · Family B', done: false }]);
  return <div className="page stack">
    <div className="page-heading"><p className="eyebrow">CLINICIAN DESK</p><h1 className="editorial">Hello, {me.replace('Dr. ', 'Dr. ').split(' ').slice(0, 2).join(' ')}.</h1>
      <p className="muted">Education, consultation, and therapy support for families.</p></div>
    <Kpis items={[[mine.length, 'Assigned to me'], [upcoming.length, 'Upcoming'], [checkins.filter(item => !item.done).length, 'Check-ins due']]} />
    <div className="scope-card"><Siren size={20} /><div><strong>Scope reminder</strong>
      <p>This service offers education and support. For warning signs or emergencies, direct families to the nearest health facility.</p></div></div>
    <NextSession item={upcoming.find(item => item.status === 'scheduled')} openRequest={openRequest} label="NEXT CONSULTATION" />
    <section>
      <div className="section-row"><h2 className="editorial section-title">My consultations</h2><button className="text-link" onClick={goRequests}>All requests<ArrowRight size={14} /></button></div>
      {mine.length ? <div className="staff-list">{mine.map(item => <MiniRequest key={item.id} item={item} openRequest={openRequest} />)}</div>
        : <p className="muted">Nothing assigned yet.</p>}
    </section>
    <section>
      <h2 className="editorial section-title">Education talking points</h2>
      <div className="focus-list">{FOCUS.map(item => {
        const on = prepared.includes(item.id);
        return <button key={item.id} className={`focus-item ${on ? 'on' : ''}`} aria-pressed={on}
          onClick={() => setPrepared(previous => on ? previous.filter(id => id !== item.id) : [...previous, item.id])}>
          <span className="check-box">{on && <Check size={13} />}</span><span><strong>{item.title}</strong><small>{item.tip}</small></span></button>;
      })}</div>
    </section>
    <section>
      <h2 className="editorial section-title">Therapy check-ins</h2>
      <div className="focus-list">{checkins.map(item => <button key={item.id} className={`focus-item ${item.done ? 'on' : ''}`} aria-pressed={item.done}
        onClick={() => setCheckins(previous => previous.map(entry => entry.id === item.id ? { ...entry, done: !entry.done } : entry))}>
        <span className="check-box">{item.done && <Check size={13} />}</span><span><strong>{item.label}</strong><small>{item.done ? 'Completed (simulated)' : 'Due this week'}</small></span></button>)}</div>
    </section>
  </div>;
}

export function AdminHome({ queue, team, openRequest, goRequests, goTeam }: Omit<Common, 'notify'> & { team: StaffMember[]; goRequests: () => void; goTeam: () => void }) {
  const count = (statuses: QueueItem['status'][]) => queue.filter(item => statuses.includes(item.status)).length;
  const unassigned = queue.filter(item => item.status === 'new' || item.status === 'in_review');
  const maxLoad = Math.max(1, ...team.map(member => queue.filter(item => item.assignee === member.name && OPEN.includes(item.status)).length));
  const topics = CONSULTATION_TYPES.map(type => ({ label: type.labelEn, value: queue.filter(item => item.typeId === type.id).length }));
  const maxTopic = Math.max(1, ...topics.map(topic => topic.value));
  return <div className="page stack">
    <div className="page-heading"><p className="eyebrow">ADMIN OVERVIEW</p><h1 className="editorial">Service at a glance</h1></div>
    <Kpis items={[[count(['new']), 'New'], [count(['in_review', 'assigned']), 'In progress'], [count(['scheduled']), 'Scheduled'], [count(['completed']), 'Done']]} />
    {unassigned.length > 0 && <button className="attention" onClick={goRequests}>
      <span className="attention-count">{unassigned.length}</span><span><strong>Waiting for assignment</strong><small>{unassigned.map(item => item.id).join(' · ')}</small></span><ArrowRight size={18} /></button>}
    <section className="panel">
      <div className="section-row"><h2 className="editorial section-title">Team workload</h2><button className="text-link" onClick={goTeam}>Manage<ArrowRight size={14} /></button></div>
      {team.map(member => {
        const load = queue.filter(item => item.assignee === member.name && OPEN.includes(item.status)).length;
        return <div className="bar-row" key={member.id}><span>{member.name}</span><div className="bar"><i style={{ width: `${(load / maxLoad) * 100}%` }} /></div><b>{load}</b></div>;
      })}
    </section>
    <section className="panel">
      <h2 className="editorial section-title">Requests by topic</h2>
      {topics.map(topic => <div className="bar-row" key={topic.label}><span>{topic.label}</span><div className="bar alt"><i style={{ width: `${(topic.value / maxTopic) * 100}%` }} /></div><b>{topic.value}</b></div>)}
    </section>
    <section>
      <h2 className="editorial section-title">Latest requests</h2>
      <div className="staff-list">{queue.slice(0, 3).map(item => <MiniRequest key={item.id} item={item} openRequest={openRequest} />)}</div>
    </section>
  </div>;
}

export function AddMemberSheet({ onClose, onAdd, specialties }: {
  onClose: () => void;
  onAdd: (member: Omit<StaffMember, 'id' | 'isNew' | 'title'>) => void;
  specialties: string[];
}) {
  const [name, setName] = useState('');
  const [role, setRole] = useState<StaffMember['role']>('counselor');
  const [specialty, setSpecialty] = useState(specialties[0]);
  return <div className="sheet-backdrop" onClick={onClose}>
    <form className="sheet" role="dialog" aria-label="Add team member" onClick={event => event.stopPropagation()}
      onSubmit={event => { event.preventDefault(); if (name.trim()) onAdd({ name: name.trim(), role, specialty }); }}>
      <span className="sheet-grip" />
      <h2 className="editorial"><UserPlus size={20} /> Add team member</h2>
      <label className="field"><span>Display name</span>
        <input value={name} onChange={event => setName(event.target.value)} maxLength={24} placeholder="First name and initial, e.g. Mimi K." autoComplete="off" autoFocus /></label>
      <div className="field"><span>Role</span>
        <div className="role-grid two">{(['counselor', 'clinician'] as const).map(item => <button type="button" key={item} className={role === item ? 'active' : ''} aria-pressed={role === item} onClick={() => setRole(item)}>
          <strong>{item === 'counselor' ? 'Counselor' : 'Clinician'}</strong><small>{item === 'counselor' ? 'Nutrition & education' : 'NCD & therapy'}</small></button>)}</div></div>
      <div className="field"><span>Focus area</span>
        <div className="chip-row inline">{specialties.map(item => <button type="button" key={item} className={`chip ${specialty === item ? 'active' : ''}`} aria-pressed={specialty === item} onClick={() => setSpecialty(item)}>{item}</button>)}</div></div>
      <p className="staff-note">Use a fictional or first-name entry. Nothing is stored or sent, and no invitation is emailed.</p>
      <button type="submit" className="button button-primary" disabled={!name.trim()}><Plus size={17} />Add to team</button>
      <button type="button" className="button button-quiet" onClick={onClose}>Cancel</button>
    </form>
  </div>;
}
