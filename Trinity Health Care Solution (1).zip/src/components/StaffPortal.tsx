import { useState, type Dispatch, type SetStateAction } from 'react';
import { ArrowLeft, ArrowRight, Check, ChevronRight, Clock3, Home, Inbox, Laptop, ListChecks, LogOut, MapPin, ShieldCheck, UserPlus, Users, X } from 'lucide-react';
import { CONSULTATION_TYPES } from '../data/opalData';
import { PERSONA, ROLE_TITLE, SLOTS, SPECIALTIES, STAFF_ROLES, STAFF_STATUS, WORKFLOW, type QueueItem, type StaffMember, type StaffRole, type StaffStatus } from '../data/staffData';
import { AddMemberSheet, AdminHome, ClinicianHome, CounselorHome } from './StaffDashboards';
import trinityMark from '../assets/trinity-mark.png';

interface Props {
  queue: QueueItem[];
  setQueue: Dispatch<SetStateAction<QueueItem[]>>;
  team: StaffMember[];
  setTeam: Dispatch<SetStateAction<StaffMember[]>>;
  onExit: () => void;
}

type Tab = 'home' | 'requests' | 'team';
type Filter = 'all' | 'mine' | 'new' | 'active' | 'done';

const typeLabel = (id: string) => CONSULTATION_TYPES.find(item => item.id === id)?.labelEn ?? id;
const now = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

function StatusPill({ status }: { status: StaffStatus }) {
  const info = STAFF_STATUS[status];
  return <span className={`staff-pill tone-${info.tone}`}>{info.label}</span>;
}

export default function StaffPortal({ queue, setQueue, team, setTeam, onExit }: Props) {
  const [role, setRole] = useState<StaffRole | null>(null);
  const [tab, setTab] = useState<Tab>('home');
  const [openId, setOpenId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const roleInfo = STAFF_ROLES.find(item => item.id === role);
  const me = role ? PERSONA[role] : null;

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(current => current === message ? null : current), 2600);
  }

  function update(id: string, patch: Partial<QueueItem>, entry?: string) {
    setQueue(previous => previous.map(item => item.id !== id ? item : {
      ...item, ...patch,
      timeline: entry ? [...item.timeline, { label: entry, at: now() }] : item.timeline,
    }));
    if (entry) notify(entry);
  }

  function addMember(member: Omit<StaffMember, 'id' | 'isNew' | 'title'>) {
    setTeam(previous => [...previous, { ...member, id: `st-${Date.now()}`, title: ROLE_TITLE[member.role], isNew: true }]);
    setAdding(false);
    notify(`${member.name} added to the team (simulated)`);
  }

  function removeMember(id: string) {
    setTeam(previous => previous.filter(member => member.id !== id));
    notify('Team member removed');
  }

  function signOut() { setRole(null); setOpenId(null); setTab('home'); }

  if (!role) return <div className="app-shell staff-shell"><LoginScreen onSignIn={setRole} onExit={onExit} /></div>;

  const open = queue.find(item => item.id === openId);
  const goRequests = () => { setOpenId(null); setTab('requests'); };
  const openRequest = (id: string) => setOpenId(id);
  return <div className="app-shell staff-shell">
    <header className="staff-header">
      {open ? <button className="staff-icon" onClick={() => setOpenId(null)} aria-label="Back"><ArrowLeft size={20} /></button>
        : <img className="brand-mark" style={{ height: 30 }} src={trinityMark} alt="" />}
      <div className="staff-header-title"><strong>{open ? open.id : me ?? 'Administrator'}</strong><span>{open ? 'Request detail' : `${roleInfo?.label} · demo session`}</span></div>
      <span className="staff-avatar" aria-hidden="true">{(me ?? 'A').replace('Dr. ', '')[0]}</span>
    </header>
    <main className="app-content mobile-scroll staff-main" tabIndex={-1}>
      {open ? <RequestDetail item={open} update={update} role={role} me={me} team={team} />
        : tab === 'home' ? (role === 'counselor' && me ? <CounselorHome queue={queue} me={me} openRequest={openRequest} notify={notify} goRequests={goRequests} />
          : role === 'clinician' && me ? <ClinicianHome queue={queue} me={me} openRequest={openRequest} notify={notify} goRequests={goRequests} />
            : <AdminHome queue={queue} team={team} openRequest={openRequest} goRequests={goRequests} goTeam={() => setTab('team')} />)
          : tab === 'requests' ? <Dashboard queue={queue} openRequest={openRequest} me={me} />
            : <TeamScreen queue={queue} team={team} canManage={role === 'admin'} onAdd={() => setAdding(true)} onRemove={removeMember} />}
    </main>
    {!open && <nav className="bottom-nav staff-nav" aria-label="Staff navigation">
      <button className={tab === 'home' ? 'active' : ''} onClick={() => setTab('home')}><span className="nav-icon"><Home size={22} /></span><span>Home</span></button>
      <button className={tab === 'requests' ? 'active' : ''} onClick={() => setTab('requests')}><span className="nav-icon"><ListChecks size={22} /></span><span>Requests</span></button>
      <button className={tab === 'team' ? 'active' : ''} onClick={() => setTab('team')}><span className="nav-icon"><Users size={22} /></span><span>Team</span></button>
      <button onClick={signOut}><span className="nav-icon"><LogOut size={22} /></span><span>Sign out</span></button>
    </nav>}
    {toast && <div className="staff-toast" role="status"><Check size={15} />{toast}<button onClick={() => setToast(null)} aria-label="Dismiss"><X size={14} /></button></div>}
    {adding && <AddMemberSheet onClose={() => setAdding(false)} onAdd={addMember} specialties={SPECIALTIES} />}
    <div className="phone-home-indicator" aria-hidden="true"><span /></div>
  </div>;
}

function LoginScreen({ onSignIn, onExit }: { onSignIn: (role: StaffRole) => void; onExit: () => void }) {
  const [staffId, setStaffId] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<StaffRole>('counselor');
  const ready = staffId.trim() && password.trim();
  return <div className="staff-login">
    <div className="staff-login-top">
      <img src={trinityMark} alt="Trinity Health Solution" />
      <p className="eyebrow">STAFF PORTAL</p>
      <h1 className="editorial">Welcome back to care.</h1>
      <p>Review consultation requests, assign the right colleague, and keep families informed.</p>
    </div>
    <form className="staff-login-form" onSubmit={event => { event.preventDefault(); if (ready) onSignIn(role); }}>
      <div className="role-grid" role="group" aria-label="Sign in as">
        {STAFF_ROLES.map(item => <button type="button" key={item.id} className={role === item.id ? 'active' : ''} aria-pressed={role === item.id} onClick={() => setRole(item.id)}>
          <strong>{item.label}</strong><small>{item.hint}</small></button>)}
      </div>
      <label className="field"><span>Staff ID</span>
        <input value={staffId} onChange={event => setStaffId(event.target.value)} placeholder="e.g. THS-0000" autoComplete="off" maxLength={20} /></label>
      <label className="field"><span>Password</span>
        <input type="password" value={password} onChange={event => setPassword(event.target.value)} placeholder="••••••••" autoComplete="off" maxLength={40} /></label>
      <button type="submit" className="button button-primary" disabled={!ready}>Sign in<ArrowRight size={17} /></button>
      <button type="button" className="button button-secondary" onClick={() => onSignIn(role)}>Continue with demo access</button>
      <p className="staff-note"><ShieldCheck size={14} />Prototype sign-in: nothing is checked, stored, or sent. Sample requests are fictional and hold no personal details.</p>
    </form>
    <button className="staff-exit" onClick={onExit}>Back to the family app</button>
  </div>;
}

function Dashboard({ queue, openRequest, me }: { queue: QueueItem[]; openRequest: (id: string) => void; me: string | null }) {
  const [filter, setFilter] = useState<Filter>('all');
  const count = (statuses: StaffStatus[]) => queue.filter(item => statuses.includes(item.status)).length;
  const groups: Record<Filter, StaffStatus[]> = {
    all: ['new', 'in_review', 'assigned', 'scheduled', 'completed', 'declined'], mine: [], new: ['new'],
    active: ['in_review', 'assigned', 'scheduled'], done: ['completed', 'declined'],
  };
  const shown = queue.filter(item => filter === 'mine' ? item.assignee === me : groups[filter].includes(item.status));
  return <div className="page stack">
    <div className="page-heading"><p className="eyebrow">ALL REQUESTS</p><h1 className="editorial">Consultation requests</h1></div>
    <div className="kpi-row">
      <div className="kpi"><strong>{count(['new'])}</strong><span>New</span></div>
      <div className="kpi"><strong>{count(['in_review', 'assigned'])}</strong><span>In progress</span></div>
      <div className="kpi"><strong>{count(['scheduled'])}</strong><span>Scheduled</span></div>
      <div className="kpi"><strong>{count(['completed'])}</strong><span>Done</span></div>
    </div>
    <div className="topic-chips no-scrollbar" role="group" aria-label="Filter requests">
      {([['all', 'All'], ...(me ? [['mine', 'Mine']] : []), ['new', 'New'], ['active', 'Active'], ['done', 'Closed']] as [Filter, string][]).map(([id, label]) =>
        <button key={id} className={`chip ${filter === id ? 'active' : ''}`} aria-pressed={filter === id} onClick={() => setFilter(id)}>{label}</button>)}
    </div>
    {shown.length ? <div className="staff-list">{shown.map(item => <button key={item.id} className="staff-card" onClick={() => openRequest(item.id)}>
      <div className="staff-card-top"><strong>{item.id}</strong>{item.source === 'family' && <span className="staff-pill tone-lime">From family app</span>}<StatusPill status={item.status} /></div>
      <span className="staff-card-title">{typeLabel(item.typeId)}</span>
      <div className="staff-card-meta">
        <span>{item.format === 'online' ? <Laptop size={13} /> : <MapPin size={13} />}{item.format === 'online' ? 'Online' : 'In person'}</span>
        <span><Clock3 size={13} />{item.received}</span>
        <span className="grow">{item.assignee ?? 'Unassigned'}</span><ChevronRight size={16} />
      </div>
    </button>)}</div> : <div className="empty-state"><span className="empty-icon"><Inbox size={26} /></span><h2 className="editorial">Nothing here</h2>
      <p className="muted">Create a demo request in the family app and it will appear in this queue.</p></div>}
  </div>;
}

function RequestDetail({ item, update, role, me, team }: { item: QueueItem; update: (id: string, patch: Partial<QueueItem>, entry?: string) => void; role: StaffRole; me: string | null; team: StaffMember[] }) {
  const [assignee, setAssignee] = useState(item.assignee ?? me ?? team[0]?.name ?? '');
  const [slot, setSlot] = useState(item.slot ?? SLOTS[0]);
  const stepIndex = Math.max(0, WORKFLOW.findIndex(step => step.status === item.status));
  const closed = item.status === 'completed' || item.status === 'declined';
  return <div className="page stack">
    <section className="detail-summary">
      <div className="staff-card-top"><StatusPill status={item.status} />{item.source === 'family' && <span className="staff-pill tone-lime">From family app</span>}</div>
      <h1 className="editorial">{typeLabel(item.typeId)}</h1>
      <div className="staff-card-meta">
        <span>{item.format === 'online' ? <Laptop size={13} /> : <MapPin size={13} />}{item.format === 'online' ? 'Online' : 'In person'}</span>
        <span><Clock3 size={13} />{item.received}</span>
      </div>
      <p className="staff-note"><ShieldCheck size={14} />No name, phone, address, or health history is collected. Contact is not possible in this prototype.</p>
    </section>

    {item.profileContext && <section className="profile-context">
      <div className="profile-context-heading"><ShieldCheck size={17} /><div><h2>Optional family context</h2><p>Broad selections from the family app, for this demo request only.</p></div></div>
      <dl>{item.profileContext.entries.map(entry => <div key={entry.label}><dt>{entry.label}</dt><dd>{entry.value}</dd></div>)}</dl>
    </section>}

    {item.status !== 'declined' && <ol className="stepper" aria-label="Request progress">
      {WORKFLOW.map((step, index) => <li key={step.status} className={index < stepIndex ? 'done' : index === stepIndex ? 'current' : ''}>
        <span>{index < stepIndex ? <Check size={12} /> : index + 1}</span>{step.label}</li>)}
    </ol>}

    {(item.assignee || item.slot) && <div className="detail-facts">
      {item.assignee && <div><small>Assigned to</small><strong>{item.assignee}</strong></div>}
      {item.slot && <div><small>Session</small><strong>{item.slot}</strong></div>}
    </div>}

    {!closed && <section className="action-panel">
      <h2 className="editorial">Next step</h2>
      {item.status === 'new' && <>
        <p>Read the request and confirm it fits the service scope.</p>
        <button className="button button-primary" onClick={() => update(item.id, { status: 'in_review' }, 'Review started')}>Start review<ArrowRight size={17} /></button>
      </>}
      {item.status === 'in_review' && <>
        <p>Choose who should take this request.</p>
        <div className="option-list">{team.map(member => <button key={member.id} className={assignee === member.name ? 'selected' : ''} aria-pressed={assignee === member.name} onClick={() => setAssignee(member.name)}>
          <strong>{member.name}{member.name === me ? ' (you)' : ''}</strong><small>{member.title} · {member.specialty}</small></button>)}</div>
        <button className="button button-primary" onClick={() => update(item.id, { status: 'assigned', assignee }, `Assigned to ${assignee}`)}>Assign to {assignee}<ArrowRight size={17} /></button>
      </>}
      {item.status === 'assigned' && <>
        <p>Pick a simulated session slot. No one is contacted.</p>
        <div className="chip-row inline">{SLOTS.map(option => <button key={option} className={`chip ${slot === option ? 'active' : ''}`} aria-pressed={slot === option} onClick={() => setSlot(option)}>{option}</button>)}</div>
        <button className="button button-primary" onClick={() => update(item.id, { status: 'scheduled', slot }, `Scheduled · ${slot}`)}>Schedule session<ArrowRight size={17} /></button>
      </>}
      {item.status === 'scheduled' && <>
        <p>After the session, close the request.</p>
        <button className="button button-primary" onClick={() => update(item.id, { status: 'completed' }, 'Completed')}><Check size={17} />Mark completed</button>
      </>}
      {(role === 'admin' || item.status !== 'new') && <button className="button button-quiet" onClick={() => update(item.id, { status: 'declined' }, 'Declined (out of scope)')}>Decline request</button>}
    </section>}

    <section className="note-block">
      <label htmlFor="staff-note"><strong>Internal note</strong><small>No personal or health details</small></label>
      <textarea id="staff-note" value={item.note} maxLength={200} rows={3} placeholder="Add a short working note…"
        onChange={event => update(item.id, { note: event.target.value })} />
    </section>

    <section>
      <h2 className="editorial section-title">Activity</h2>
      <ol className="activity">{[...item.timeline].reverse().map((entry, index) => <li key={`${entry.label}-${index}`}><span className="dot" /><div><strong>{entry.label}</strong><small>{entry.at}</small></div></li>)}</ol>
    </section>
  </div>;
}

function TeamScreen({ queue, team, canManage, onAdd, onRemove }: { queue: QueueItem[]; team: StaffMember[]; canManage: boolean; onAdd: () => void; onRemove: (id: string) => void }) {
  const [away, setAway] = useState<string[]>([]);
  return <div className="page stack">
    <div className="page-heading"><p className="eyebrow">YOUR TEAM</p><h1 className="editorial">Care team</h1></div>
    {canManage ? <button className="button button-primary" onClick={onAdd}><UserPlus size={17} />Add team member</button>
      : <p className="staff-note"><ShieldCheck size={14} />Only an admin can add or remove team members.</p>}
    <div className="staff-list">{team.map(member => {
      const load = queue.filter(item => item.assignee === member.name && item.status !== 'completed' && item.status !== 'declined').length;
      const isAway = away.includes(member.id);
      return <div key={member.id} className="staff-card team-card">
        <span className="staff-avatar big">{member.name.replace('Dr. ', '')[0]}</span>
        <div className="grow"><strong>{member.name}{member.isNew && <span className="staff-pill tone-lime new-tag">New</span>}</strong><span className="staff-card-title">{member.title}</span><small>{member.specialty}</small></div>
        <div className="team-side"><span className={`staff-pill ${isAway ? 'tone-grey' : 'tone-green'}`}>{isAway ? 'Away' : 'Available'}</span><small>{load} open</small>
          <button className="text-link" onClick={() => setAway(previous => isAway ? previous.filter(id => id !== member.id) : [...previous, member.id])}>{isAway ? 'Set available' : 'Set away'}</button>
          {canManage && member.isNew && <button className="text-link danger" onClick={() => onRemove(member.id)}>Remove</button>}</div>
      </div>;
    })}</div>
    <p className="staff-note"><ShieldCheck size={14} />Team members are fictional examples for this simulation.</p>
  </div>;
}
