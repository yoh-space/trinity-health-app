import { useState } from 'react';
import { ArrowDown, ArrowRight, Check, ChevronDown, Clock3, CookingPot, SlidersHorizontal } from 'lucide-react';
import { ALLERGY_OPTIONS, BUNDLED_RECIPES, FAMILIAR_INGREDIENTS, type AllergyId, type Language, type MealAudience } from '../data/opalData';
import { Button, Choice, EmptyState, Heading, Notice, SectionHeading, type Translate } from './OpalUI';
import { TibebBorder } from './WovenMotifs';

export default function MealsScreen({ lang, t }: { lang: Language; t: Translate }) {
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [allergies, setAllergies] = useState<AllergyId[]>([]);
  const [audience, setAudience] = useState<MealAudience>('family');
  const [showResults, setShowResults] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const results = BUNDLED_RECIPES.filter(recipe => recipe.audiences.includes(audience)
    && recipe.matchedIngredients.some(id => ingredients.includes(id))
    && !recipe.containsAllergens.some(id => allergies.includes(id)))
    .sort((a, b) => b.matchedIngredients.filter(id => ingredients.includes(id)).length - a.matchedIngredients.filter(id => ingredients.includes(id)).length);
  const change = (callback: () => void) => { callback(); setShowResults(false); setExpanded(null); };
  const toggleAllergy = (id: AllergyId) => change(() => {
    if (id === 'none') setAllergies(allergies.includes('none') ? [] : ['none']);
    else setAllergies(allergies.includes(id) ? allergies.filter(item => item !== id) : [...allergies.filter(item => item !== 'none'), id]);
  });
  return <div className="page stack">
    <Heading eyebrow={t('በኩሽና ውስጥ እንጀምር', 'LET’S START IN THE KITCHEN')} title={t('ዛሬ ምን እናብስል?', 'Something good from what you have.')}
      description={t('የተለመዱ ግብዓቶች። ቀላል የቤት ምግብ ሀሳቦች።', 'Familiar ingredients. Simple ideas for the family table.')} />
    <SectionHeading title={t('01  በቤትዎ ምን አለ?', '01  What’s in your kitchen?')} />
    <div className="ingredient-grid" role="group" aria-label={t('ግብዓቶች', 'Ingredients')}>
      {FAMILIAR_INGREDIENTS.map(item => <button key={item.id} className={`ingredient ${ingredients.includes(item.id) ? 'active' : ''}`}
        aria-pressed={ingredients.includes(item.id)} onClick={() => change(() => setIngredients(ingredients.includes(item.id)
          ? ingredients.filter(id => id !== item.id) : [...ingredients, item.id]))}>
        <span className="ingredient-check">{ingredients.includes(item.id) ? <Check size={12} /> : '+'}</span>
        {lang === 'am' ? item.nameAm.split(' (')[0] : item.nameEn.split(' (')[0]}
      </button>)}
    </div>
    <SectionHeading title={t('02  ማንን እንመግባለን?', '02  Who’s gathering at the table?')} />
    <div className="choice-list">
      <Choice title={t('ቤተሰብ', 'The family')} selected={audience === 'family'} onClick={() => change(() => setAudience('family'))} />
      <Choice title={t('ታዳጊ ህፃን · ከ6 ወር በላይ', 'A young child · 6 months or older')} selected={audience === 'young_child'}
        onClick={() => change(() => setAudience('young_child'))} />
    </div>
    {audience === 'young_child' && <Notice>{t('እነዚህ የሙከራ ሀሳቦች ከ6 ወር በታች ላሉ ህፃናት አይደሉም። ለልጅዎ የመመገብ ዝግጁነትና አወቃቀር ብቁ ባለሙያን ያማክሩ።', 'These sample ideas are not for infants under 6 months. Ask a qualified health worker about feeding readiness and age-appropriate textures.')}</Notice>}
    <SectionHeading title={t('03  የማይካተቱ ነገሮች', '03  Anything to leave out?')} />
    <p className="small-note">{t('ለዚህ ሙከራ ብቻ ምርጫ ያድርጉ። ምርጫዎች አይቀመጡም።', 'Choose demo allergy exclusions, or “No declared allergy.” These choices are never stored.')}</p>
    <div className="allergy-chips" role="group" aria-label={t('የአለርጂ ማጣሪያዎች', 'Demo allergy exclusions')}>
      {ALLERGY_OPTIONS.map(item => <button key={item.id} className={`chip ${allergies.includes(item.id) ? 'active' : ''}`}
        aria-pressed={allergies.includes(item.id)} onClick={() => toggleAllergy(item.id)}>
        {allergies.includes(item.id) && <Check size={13} />}{lang === 'am' ? item.labelAm.split(' (')[0] : item.labelEn}
      </button>)}
    </div>
    <Notice kind="gold">{t('ይህ የአለርጂ ደህንነት ማረጋገጫ አይደለም። ማጣሪያው በተዘረዘሩ ምልክቶች ብቻ ይሠራል። ሁሉንም ግብዓቶች፣ የምርት መለያዎችና የመቀላቀል አደጋን ያረጋግጡ፤ ባለሙያን ያማክሩ።',
      'Not an allergy-safety check. Filters use listed recipe tags only and do not cover every allergen or cross-contact. Check every ingredient and product label with a qualified professional.')}</Notice>
    <Button disabled={!ingredients.length || !allergies.length} onClick={() => setShowResults(true)}>
      <CookingPot size={18} />{t('የምግብ ሀሳቦችን አሳይ', 'Find a little inspiration')}<ArrowDown size={17} />
    </Button>
    {(!ingredients.length || !allergies.length) && <p className="small-note centered">{t('ቢያንስ አንድ ግብዓት እና የአለርጂ ምርጫ ያስፈልጋል።', 'Select at least one ingredient and an allergy option to continue.')}</p>}
    {showResults && <section className="stack meal-results" aria-live="polite">
      <TibebBorder variant="subtle" />
      <SectionHeading title={t(`${results.length} የሙከራ ምግብ ሀሳቦች`, `${results.length} little ideas for your table`)} />
      <p className="small-note">{t('አንዳንድ ግብዓቶች ሊዛመዱ ይችላሉ። ከማዘጋጀትዎ በፊት ሙሉውን ዝርዝር ይመልከቱ።', 'Ideas match some, not necessarily all, of your ingredients. Review the full list; you may need other items.')}</p>
      {results.length ? results.map(recipe => <article key={recipe.id} className="recipe-card">
        <div className="recipe-top"><span className="recipe-icon"><CookingPot size={25} strokeWidth={1.3} /></span>
          <span className="meta"><Clock3 size={13} />{lang === 'am' ? recipe.cookTimeAm : recipe.cookTimeEn}</span></div>
        <h3 className="editorial">{lang === 'am' ? recipe.titleAm : recipe.titleEn}</h3>
        <p>{lang === 'am' ? recipe.subtitleAm : recipe.subtitleEn}</p>
        <div className="matched-ingredients"><Check size={14} /><span>{t('ከምርጫዎ፦ ', 'From your selection: ')}{recipe.matchedIngredients.filter(id => ingredients.includes(id))
          .map(id => { const ingredient = FAMILIAR_INGREDIENTS.find(item => item.id === id)!; return lang === 'am' ? ingredient.nameAm.split(' (')[0] : ingredient.nameEn.split(' (')[0]; }).join(' · ')}</span></div>
        <button className="recipe-toggle" aria-expanded={expanded === recipe.id} onClick={() => setExpanded(expanded === recipe.id ? null : recipe.id)}>
          {expanded === recipe.id ? t('ዝርዝሩን ዝጋ', 'Tuck the recipe away') : t('ግብዓቶችና ዝግጅት', 'Ingredients & simple steps')}<ChevronDown size={17} className={expanded === recipe.id ? 'rotated' : ''} /></button>
        {expanded === recipe.id && <div className="recipe-details">
          <h4>{t('ሙሉ የግብዓት ዝርዝር', 'What you’ll need')}</h4>
          <ul>{(lang === 'am' ? recipe.ingredientsListAm : recipe.ingredientsListEn).map(item => <li key={item}>{item}</li>)}</ul>
          <h4>{t('አብረን እናዘጋጅ', 'Let’s put it together')}</h4>
          <ol>{(lang === 'am' ? recipe.stepsAm : recipe.stepsEn).map(item => <li key={item}>{item}</li>)}</ol>
          <Notice kind="green">{lang === 'am' ? recipe.foodSafetyNoteAm : recipe.foodSafetyNoteEn}</Notice>
        </div>}
      </article>) : <EmptyState title={t('ሌላ ግብዓት እንሞክር?', 'A different ingredient, perhaps?')}
        description={t('ከሙከራ ማስታወሻዎቻችን የሚዛመድ ሀሳብ አልተገኘም። ሌላ ግብዓት ይጨምሩ፤ ለማዛመድ ብለው የአለርጂ ምርጫን አያስወግዱ።', 'No bundled recipe matches these choices. Try adding another ingredient, but don’t remove an allergy exclusion just to get a match.')} />}
    </section>}
    <p className="small-note centered">{t('የቀጥታ መረጃ የለም። 3 በአካባቢ የተካተቱ የሙከራ አዘገጃጀቶች ብቻ።', 'No live generation. Just 3 locally bundled sample recipes.')}</p>
  </div>;
}
