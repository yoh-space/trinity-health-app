import { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Lock, ShieldCheck } from 'lucide-react';
import trinityMark from '../assets/trinity-mark.png';
import {
  ACTIVITY, AGES, CONDITIONS, DIET, FOR_WHO, FORMATS, GOALS, MEALS, labelOf, type Option, type Profile,
} from '../lib/profile';
import type { Language } from '../data/opalData';
import type { Translate } from './OpalUI';

interface Props {
  lang: Language;
  t: Translate;
  initial: Profile;
  onFinish: (profile: Profile, remember: boolean) => void;
  onSkip: () => void;
  onBack: () => void;
}

const STEPS = 5;

function Options({ list, lang, value, onChange, multi = false, columns = 1, max }: {
  list: Option[]; lang: Language; value: string | string[]; onChange: (next: string) => void; multi?: boolean; columns?: 1 | 2 | 3; max?: number;
}) {
  const selected = (id: string) => Array.isArray(value) ? value.includes(id) : value === id;
  return <div className={`ob-options cols-${columns}`} role={multi ? 'group' : 'radiogroup'}>
    {list.map(item => {
      const on = selected(item.id);
      const locked = multi && !on && max !== undefined && Array.isArray(value) && value.length >= max;
      return <button key={item.id} type="button" className={`ob-option ${on ? 'on' : ''}`} disabled={locked}
        role={multi ? 'checkbox' : 'radio'} aria-checked={on} onClick={() => onChange(item.id)}>
        <span className={`ob-mark ${multi ? 'square' : ''}`}>{on && <Check size={13} strokeWidth={3} />}</span>
        <span className="ob-copy"><strong>{item[lang]}</strong>{(lang === 'am' ? item.hintAm : item.hintEn) && <small>{lang === 'am' ? item.hintAm : item.hintEn}</small>}</span>
      </button>;
    })}
  </div>;
}

export default function ProfileOnboarding({ lang, t, initial, onFinish, onSkip, onBack }: Props) {
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState<Profile>(initial);
  const [remember, setRemember] = useState(true);
  const set = <K extends keyof Profile>(key: K, value: Profile[K]) => setProfile(previous => ({ ...previous, [key]: value }));
  const toggle = (key: 'conditions' | 'diet' | 'goals', id: string) =>
    setProfile(previous => ({ ...previous, [key]: previous[key].includes(id) ? previous[key].filter(item => item !== id) : [...previous[key], id] }));

  const titles = [
    [t('ይህ ለማን ነው?', 'Who is this for?'), t('ትምህርቶችንና ምክክርን ለእርስዎ እንዲስማሙ ለማድረግ።', 'So we can fit lessons and consultations to the right person.')],
    [t('ምን ላይ ድጋፍ ይፈልጋሉ?', 'What would you like support with?'), t('የሚመለከቱትን ሁሉ ይምረጡ። ሰፊ ምድቦች ብቻ፤ ምርመራ፣ መድኃኒት ወይም ውጤት አያስፈልግም።', 'Choose any that apply. Broad topics only. No diagnoses, medication, or test results needed.')],
    [t('የዕለት ተዕለት ኑሮ', 'Your daily routine'), t('ምክሮች ከእውነተኛ ኑሮዎ ጋር እንዲጣጣሙ።', 'So guidance fits the way you actually live and eat.')],
    [t('ግቦችዎ', 'What are your goals?'), t('እስከ 3 ይምረጡ።', 'Pick up to three.')],
    [t('የእርስዎ እቅድ ዝግጁ ነው', 'Your plan is ready'), t('ከመጀመርዎ በፊት ይመልከቱ።', 'Take a quick look before we begin.')],
  ][step];

  const summary: [string, string][] = [
    [t('ለማን', 'For'), [profile.forWho && labelOf(FOR_WHO, profile.forWho, lang), profile.age && labelOf(AGES, profile.age, lang)].filter(Boolean).join(' · ')],
    [t('ትኩረት', 'Focus'), profile.conditions.map(id => labelOf(CONDITIONS, id, lang)).join(', ')],
    [t('ሌላ ድጋፍ', 'Other support'), profile.customSupport],
    [t('ኑሮ', 'Routine'), [profile.meals && `${labelOf(MEALS, profile.meals, lang)} ${t('ምግቦች', 'meals/day')}`, profile.activity && labelOf(ACTIVITY, profile.activity, lang), ...profile.diet.map(id => labelOf(DIET, id, lang))].filter(Boolean).join(' · ')],
    [t('ግቦች', 'Goals'), profile.goals.map(id => labelOf(GOALS, id, lang)).join(', ')],
    [t('ሌላ ግብ', 'Other goal'), profile.customGoal],
    [t('ምክክር', 'Consultation'), profile.format && labelOf(FORMATS, profile.format, lang)],
    [t('ሌላ የምክክር ምርጫ', 'Other consultation preference'), profile.customFormat],
  ];

  return <div className="ob">
    <header className="ob-top">
      <button className="ob-back" onClick={step === 0 ? onBack : () => setStep(step - 1)} aria-label={t('ተመለስ', 'Back')}><ArrowLeft size={20} /></button>
      <div className="ob-progress" role="progressbar" aria-valuemin={1} aria-valuemax={STEPS} aria-valuenow={step + 1} aria-label={t('እድገት', 'Progress')}>
        {Array.from({ length: STEPS }, (_, index) => <i key={index} className={index <= step ? 'on' : ''} />)}
      </div>
      <span className="ob-count">{step + 1}/{STEPS}</span>
    </header>

    <div className="ob-body">
      {step === 0 && <img className="ob-logo" src={trinityMark} alt="" />}
      <p className="eyebrow">{t('የእርስዎ የጤና መገለጫ', 'YOUR HEALTH PROFILE')}</p>
      <h1 className="editorial">{titles[0]}</h1>
      <p className="muted">{titles[1]}</p>

      {step === 0 && <>
        <Options list={FOR_WHO} lang={lang} value={profile.forWho} onChange={id => set('forWho', id)} columns={2} />
        <p className="ob-label">{t('የእድሜ ክልል', 'Age range')}</p>
        <Options list={AGES} lang={lang} value={profile.age} onChange={id => set('age', id)} columns={3} />
      </>}

      {step === 1 && <>
        <Options list={CONDITIONS} lang={lang} value={profile.conditions} onChange={id => toggle('conditions', id)} multi columns={2} />
        <button type="button" className={`ob-option wide ${profile.conditions.length === 0 ? 'on' : ''}`} onClick={() => set('conditions', [])}>
          <span className="ob-mark">{profile.conditions.length === 0 && <Check size={13} strokeWidth={3} />}</span>
          <span className="ob-copy"><strong>{t('መግለጽ አልፈልግም / አጠቃላይ ጤና', 'General wellness / prefer not to say')}</strong></span></button>
        <label className="ob-custom-support">
          <span>{t('ሌላ የሚፈልጉት ድጋፍ (አማራጭ)', 'Other support topic (optional)')}</span>
          <textarea value={profile.customSupport} maxLength={120} rows={3}
            placeholder={t('ለምሳሌ፦ ለቤተሰብ ጤናማ ምግብ ማዘጋጀት', 'For example: planning healthier family meals')}
            onChange={event => set('customSupport', event.target.value)} />
          <small>{t('አጠቃላይ ርዕስ ብቻ ይጻፉ። ስም፣ የጤና ምርመራ፣ መድኃኒት ወይም የምርመራ ውጤት አይጻፉ።', 'Share a general topic only. Do not include names, diagnoses, medicines, or test results.')}</small>
        </label>
      </>}

      {step === 2 && <>
        <p className="ob-label">{t('በቀን ስንት ምግብ?', 'Meals per day')}</p>
        <Options list={MEALS} lang={lang} value={profile.meals} onChange={id => set('meals', id)} columns={3} />
        <p className="ob-label">{t('የአካል እንቅስቃሴ', 'Physical activity')}</p>
        <Options list={ACTIVITY} lang={lang} value={profile.activity} onChange={id => set('activity', id)} />
        <p className="ob-label">{t('የአመጋገብ ሁኔታ (አማራጭ)', 'Eating pattern (optional)')}</p>
        <Options list={DIET} lang={lang} value={profile.diet} onChange={id => toggle('diet', id)} multi columns={2} />
      </>}

      {step === 3 && <>
        <Options list={GOALS} lang={lang} value={profile.goals} onChange={id => toggle('goals', id)} multi max={3} />
        <label className="ob-custom-support">
          <span>{t('ሌላ ግብ (አማራጭ)', 'Other goal (optional)')}</span>
          <textarea value={profile.customGoal} maxLength={120} rows={3}
            placeholder={t('ለምሳሌ፦ ተጨማሪ የቤተሰብ ምግብ ሀሳቦችን መማር', 'For example: learn more family meal ideas')}
            onChange={event => set('customGoal', event.target.value)} />
          <small>{t('አጠቃላይ ግብ ብቻ ይጻፉ። ስም፣ የጤና ምርመራ፣ መድኃኒት ወይም የምርመራ ውጤት አይጻፉ።', 'Share a general goal only. Do not include names, diagnoses, medicines, or test results.')}</small>
        </label>
        <p className="ob-label">{t('ምክክር እንዴት ይመርጣሉ?', 'Preferred consultation format')}</p>
        <Options list={FORMATS} lang={lang} value={profile.format} onChange={id => set('format', id)} columns={3} />
        <label className="ob-custom-support">
          <span>{t('ሌላ የምክክር ምርጫ (አማራጭ)', 'Other consultation preference (optional)')}</span>
          <textarea value={profile.customFormat} maxLength={120} rows={3}
            placeholder={t('ለምሳሌ፦ ከቤተሰብ አባል ጋር መገኘት', 'For example: attend with a family member')}
            onChange={event => set('customFormat', event.target.value)} />
          <small>{t('አጠቃላይ ምርጫ ብቻ ይጻፉ። ስም፣ ስልክ ወይም የግል ዝርዝር አይጻፉ።', 'Share a general preference only. Do not include names, phone numbers, or personal details.')}</small>
        </label>
      </>}

      {step === 4 && <>
        <dl className="ob-summary">{summary.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value || t('አልተመረጠም', 'Not specified')}</dd></div>)}</dl>
        <label className="ob-remember"><input type="checkbox" checked={remember} onChange={event => setRemember(event.target.checked)} />
          <span><strong>{t('በዚህ መሣሪያ ላይ አስቀምጥ', 'Remember on this device')}</strong>
            <small>{t('ያለዚህ፣ መልሶችዎ ለዚህ ክፍለ ጊዜ ብቻ ይቆያሉ።', 'Otherwise your answers last for this session only.')}</small></span></label>
      </>}

      <p className="ob-privacy"><Lock size={14} />{step === 4
        ? t('መልሶችዎ በዚህ መሣሪያ ላይ ብቻ ይቆያሉ። ምንም አይላክም፤ በቅንብሮች ማስወገድ ይችላሉ። ይህ የሕክምና ምክር አይደለም።', 'Answers stay on this device. Nothing is sent, and you can remove them in Settings. This is education, not medical advice.')
        : t('ሁሉም ጥያቄዎች አማራጭ ናቸው። ስም፣ ስልክ ወይም መለያ አይጠየቅም።', 'Every question is optional. No name, phone number, or account.')}</p>
    </div>

    <footer className="ob-footer">
      <button className="button button-primary" onClick={() => step === STEPS - 1 ? onFinish(profile, remember) : setStep(step + 1)}>
        {step === STEPS - 1 ? t('እቅዴን ጀምር', 'Start my plan') : step === 0 && !profile.forWho ? t('ዝለል', 'Skip this step') : t('ቀጥል', 'Continue')}<ArrowRight size={17} /></button>
      {step < STEPS - 1 && <button className="button button-quiet" onClick={onSkip}>{t('ማዋቀሩን ዝለል፣ ሁሉንም አሳይ', 'Skip setup. Show me everything.')}</button>}
      {step === STEPS - 1 && <p className="ob-trust"><ShieldCheck size={13} />{t('ማንኛውንም መልስ በኋላ መቀየር ይችላሉ።', 'You can change any answer later.')}</p>}
    </footer>
  </div>;
}
