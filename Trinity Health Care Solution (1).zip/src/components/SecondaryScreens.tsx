import { useState } from 'react';
import { ArrowRight, Bookmark, BookOpen, Check, ChevronRight, Globe2, HeartHandshake, Laptop, MapPin, MessageCircle, ShieldCheck, Trash2 } from 'lucide-react';
import { CONSULTATION_TYPES, LESSONS, type CareStage, type Language, type ScreenId } from '../data/opalData';
import { Button, Choice, EmptyState, Heading, LessonCard, Notice, SectionHeading, type Translate } from './OpalUI';
import { STAFF_STATUS, type StaffStatus } from '../data/staffData';
import { TibebBorder } from './WovenMotifs';
import trinityMark from '../assets/trinity-mark.png';

type CommonProps = { lang: Language; t: Translate };

export interface DemoRequest {
  typeId: string;
  format: 'online' | 'in_person';
  profileContext?: import('../lib/profile').ProfileContext;
}

export function CareScreen({ lang, t, request, setRequest, navigate, staffStatus }: CommonProps & {
  staffStatus?: StaffStatus;
  request: DemoRequest | null;
  setRequest: (request: DemoRequest | null) => void;
  navigate: (screen: ScreenId) => void;
}) {
  const [type, setType] = useState(CONSULTATION_TYPES[0].id);
  const [format, setFormat] = useState<'online' | 'in_person'>('online');
  const [consent, setConsent] = useState(false);
  const requestType = CONSULTATION_TYPES.find(item => item.id === request?.typeId);
  return <div className="page stack">
    <Heading eyebrow={t('እንክብካቤ፣ ከእርስዎ ጋር', 'CARE, ALONGSIDE YOU')} title={t('ትንሽ ተጨማሪ ድጋፍ', 'A little more support')}
      description={t('ለወደፊት አገልግሎት የተዘጋጀ የሙከራ ቅጽ።', 'Explore what asking for nutrition support could look like.')} />
    <div className="care-hero"><HeartHandshake size={36} strokeWidth={1.3} /><div><strong>{t('የሙከራ ጥያቄ ብቻ', 'A practice request, not a booking')}</strong>
      <p>{t('ምንም አይላክም፣ ምንም ቀጠሮ አይያዝም። ከባለሙያ ጋር አይገናኙም።', 'Nothing is sent or booked. No clinician is contacted or assigned.')}</p></div></div>
    {request ? <>
      <section className="request-result" aria-live="polite">
        <span className="result-icon"><Check size={25} /></span>
        <p className="eyebrow">{t('በዚህ ክፍለ ጊዜ ብቻ የተቀመጠ', 'SESSION-ONLY DEMO RECORD')}</p>
        <h2 className="editorial">Requested — not yet confirmed</h2>
        {lang === 'am' && <p>ተጠይቋል — ገና አልተረጋገጠም</p>}
        <p>{lang === 'am' ? requestType?.labelAm.split(' (')[0] : requestType?.labelEn}</p>
        <span className="pill">{request.format === 'online' ? t('በኢንተርኔት · የሙከራ', 'Online · simulated') : t('በአካል · የሙከራ', 'In person · simulated')}</span>
        {request.profileContext && <p className="small-note">{t('የመገለጫ ምርጫዎችዎ በሙከራ የሠራተኛ እይታ ውስጥ ተካተዋል።', 'Your optional profile choices are included in the simulated staff view.')}</p>}
        {staffStatus && staffStatus !== 'new' && <p className="small-note">{t('የሙከራ ሠራተኛ እይታ፦ ', 'Simulated staff view: ')}{STAFF_STATUS[staffStatus].label}</p>}
        <TibebBorder variant="subtle" />
        <p>{t('ምንም አልተላከም ወይም አልተያዘም። ማረጋገጫ፣ ጥሪ ወይም ምላሽ አይመጣም።', 'Nothing was sent or booked. There will be no confirmation, callback, or follow-up.')}</p>
        <Button variant="secondary" onClick={() => { setRequest(null); setConsent(false); }}>{t('የሙከራ ጥያቄውን አስወግድ', 'Remove demo request')}</Button>
      </section>
    </> : <>
      <SectionHeading title={t('01  የድጋፍ አይነት', '01  Choose a topic')} />
      <div className="choice-list">{CONSULTATION_TYPES.map(item => <Choice key={item.id} selected={type === item.id}
        title={lang === 'am' ? item.labelAm.split(' (')[0] : item.labelEn}
        onClick={() => setType(item.id)} />)}</div>
      <SectionHeading title={t('02  የመገናኛ መንገድ', '02  A preferred format')} />
      <div className="format-grid">
        <Choice title={t('በኢንተርኔት', 'Online')} icon={<Laptop size={22} />} selected={format === 'online'} onClick={() => setFormat('online')} />
        <Choice title={t('በአካል', 'In person')} icon={<MapPin size={22} />} selected={format === 'in_person'} onClick={() => setFormat('in_person')} />
      </div>
      <label className="check-label"><input type="checkbox" checked={consent} onChange={event => setConsent(event.target.checked)} />
        <span>{t('ይህ የሙከራ ጥያቄ ብቻ መሆኑን ተረድቻለሁ። ምንም አይላክም ወይም አይያዝም።', 'I understand this is only a simulation. Nothing is sent or booked, and no one will contact me.')}</span></label>
      <Button disabled={!consent} onClick={() => setRequest({ typeId: type, format })}>{t('የሙከራ ጥያቄ ፍጠር', 'Create a demo request')}<ArrowRight size={17} /></Button>
    </>}
    <button className="inline-care-link" onClick={() => navigate('ask-opal')}><MessageCircle size={23} /><span><strong>{t('አጠቃላይ ጥያቄ አለዎት?', 'Just looking to learn?')}</strong><small>{t('ኦፓልን ይጠይቁ · የተዘጋጁ መልሶች', 'Ask Opal · prewritten learning answers')}</small></span><ChevronRight size={17} /></button>
    <Notice>{t('ስም፣ ስልክ፣ አድራሻ ወይም የጤና ዝርዝር አንጠይቅም። ለአስቸኳይ እርዳታ የጤና ተቋምን በቀጥታ ያነጋግሩ።', 'No name, phone number, address, or health history is collected. For urgent help, contact a health facility directly.')}</Notice>
  </div>;
}

export function SavedScreen({ lang, t, saved, toggleSave, openLesson, navigate, persistent }: CommonProps & {
  saved: string[];
  toggleSave: (id: string) => void;
  openLesson: (id: string) => void;
  navigate: (screen: ScreenId) => void;
  persistent: boolean;
}) {
  const lessons = LESSONS.filter(lesson => saved.includes(lesson.id));
  return <div className="page stack">
    <Heading eyebrow={t('የእርስዎ ትንሽ ስብስብ', 'YOUR LITTLE COLLECTION')} title={t('የተቀመጡ ማስታወሻዎች', 'Saved for a quieter moment')}
      description={t('ጠቃሚ ትምህርቶችን በቅርብ ያስቀምጡ።', 'Keep the notes you want to come back to.')} />
    <Notice kind="green"><strong>{persistent ? t('በዚህ አሳሽ ተቀምጧል', 'Saved in this browser') : t('ለዚህ ክፍለ ጊዜ ብቻ', 'Available this session only')}</strong>
      <p>{t('ትምህርቶች ከዚህ ሙከራ ጋር ተካትተዋል። ያለ ኢንተርኔት እንደገና መክፈት ዋስትና የለውም።', 'Lessons are bundled with this prototype, not downloaded from a server. Reloading the app offline is not guaranteed.')}</p>
    </Notice>
    <SectionHeading title={`${t('የተቀመጡ ትምህርቶች', 'Bookmarked notes')} · ${lessons.length}`} />
    {lessons.length ? <div className="lesson-list">{lessons.map(lesson => <LessonCard key={lesson.id} lesson={lesson} lang={lang} saved
      onOpen={() => openLesson(lesson.id)} onSave={() => toggleSave(lesson.id)} />)}</div>
      : <EmptyState title={t('ለመጀመሪያው ማስታወሻ ቦታ', 'A place for your first note')}
        description={t('በማንኛውም ትምህርት ላይ የማስቀመጫ ምልክቱን ይንኩ።', 'Tap the bookmark on any lesson. It will be waiting here when you need it.')}
        action={t('ትምህርቶችን ያስሱ', 'Explore the learning library')} onAction={() => navigate('learn')} />}
  </div>;
}

export function SettingsScreen({ lang, t, setLang, stage, clearStage, navigate, clearData, persistent, openStaff }: CommonProps & {
  openStaff: () => void;
  setLang: (lang: Language) => void;
  stage: CareStage;
  clearStage: () => void;
  navigate: (screen: ScreenId) => void;
  clearData: () => void;
  persistent: boolean;
}) {
  const [confirmClear, setConfirmClear] = useState(false);
  return <div className="page stack">
    <Heading eyebrow={t('በእርስዎ መንገድ', 'MAKE YOURSELF AT HOME')} title={t('ቅንብሮች', 'Your preferences')} />
    <SectionHeading title={t('የመተግበሪያ ቋንቋ', 'Your reading language')} />
    <div className="language-switch" role="group" aria-label={t('ቋንቋ', 'Language')}>
      <button className={lang === 'am' ? 'active' : ''} onClick={() => setLang('am')} aria-pressed={lang === 'am'}><span lang="am">አማርኛ</span><small>Amharic</small>{lang === 'am' && <Check size={16} />}</button>
      <button className={lang === 'en' ? 'active' : ''} onClick={() => setLang('en')} aria-pressed={lang === 'en'}><span>English</span><small>እንግሊዝኛ</small>{lang === 'en' && <Check size={16} />}</button>
    </div>
    <SectionHeading title={t('እርስዎ ይቆጣጠሩታል', 'Always in your hands')} />
    <div className="settings-panel">
      <div className="settings-row"><ShieldCheck size={21} /><div><strong>{t('አማራጭ ግላዊ ምርጫ', 'Optional personalization')}</strong>
        <p>{stage === 'none' || stage === 'prefer_not_to_say' ? t('አጠቃላይ ትምህርቶች · ምንም ደረጃ አልተቀመጠም', 'General learning · no stage retained') : t('የክፍለ ጊዜ ምርጫ ንቁ ነው', 'Session-only choice is active')}</p></div></div>
      <Button variant="secondary" onClick={() => navigate('personalize')}>{t('ምርጫን ቀይር', 'Choose what feels relevant')}<ArrowRight size={16} /></Button>
      {stage !== 'none' && <Button variant="quiet" onClick={clearStage}>{t('ግላዊ ምርጫን አስወግድ', 'Remove session personalization')}</Button>}
    </div>
    <div className="settings-panel">
      <div className="settings-row"><Bookmark size={21} /><div><strong>{t('በእርስዎ መሣሪያ ብቻ', 'Only on your device')}</strong>
        <p>{persistent ? t('ቋንቋ፣ የመግቢያ ምርጫ እና የተቀመጡ ትምህርቶች ብቻ ይቀመጣሉ።', 'Only language, welcome completion, and bookmarks are stored in this browser.') : t('የአሳሽ ማከማቻ አይገኝም። ምርጫዎች ለዚህ ክፍለ ጊዜ ብቻ ናቸው።', 'Browser storage is unavailable. Your preferences last only for this session.')}</p></div></div>
      <p className="small-note">{t('የእንክብካቤ ደረጃ፣ አለርጂ እና የሙከራ ጥያቄዎች ወደ ማከማቻ አይጻፉም። ሲያድሱ ይጠፋሉ።', 'Care-stage choices, allergy filters, and demo requests stay in memory only and disappear on reload. No account, analytics, or data transmission.')}</p>
      {confirmClear ? <div className="clear-confirm" role="group" aria-label={t('ማጥፋትን ያረጋግጡ', 'Confirm clearing data')}>
        <strong>{t('የአካባቢያዊ ውሂብ ይጥፋ?', 'Clear your Trinity Health Solution data?')}</strong>
        <p>{t('የተቀመጡ ትምህርቶችና ምርጫዎች ይጠፋሉ። ይህ ሊመለስ አይችልም።', 'Your bookmarks and preferences will be removed. This cannot be undone.')}</p>
        <Button variant="danger" onClick={clearData}><Trash2 size={17} />{t('አዎ፣ የኦፓል ውሂብ ይጥፋ', 'Yes, clear Opal data')}</Button>
        <Button variant="quiet" onClick={() => setConfirmClear(false)}>{t('ይቅር', 'Keep my notes')}</Button>
      </div> : <Button variant="danger" onClick={() => setConfirmClear(true)}><Trash2 size={16} />{t('የአካባቢ ውሂብ አጥፋ', 'Clear local data')}</Button>}
    </div>
    <Button variant="quiet" onClick={openStaff}><ShieldCheck size={15} />{t('የሠራተኛ መግቢያ (ሙከራ)', 'Staff portal (demo)')}</Button>
    <div className="about-note"><img className="brand-mark" style={{ height: 40 }} src={trinityMark} alt="" /><strong>Trinity Health Solution</strong><span>{t('ለኢትዮጵያ ቤተሰቦች · የሙከራ ስሪት 01', 'For Ethiopian families · Prototype 01')}</span>
      <div><Globe2 size={13} />{t('በአካባቢ የተካተቱ ማስታወሻዎች ብቻ', 'Local, bundled learning notes only')}</div></div>
  </div>;
}

