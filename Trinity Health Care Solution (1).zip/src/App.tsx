import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Baby, Bookmark, BookOpen, Check, ChevronRight, CookingPot, MessageCircle, Heart, HeartHandshake, Home, Leaf, Settings, ShieldCheck, Sprout, Stethoscope, Users } from 'lucide-react';
import { CARE_STAGE_OPTIONS, LESSONS, type CareStage, type Language, type ScreenId } from './data/opalData';
import { TibebBorder } from './components/WovenMotifs';
import trinityMark from './assets/trinity-mark.png';
import { Button, Choice, Heading, IconButton, Notice, type Translate } from './components/OpalUI';
import { HomeScreen, LearnScreen, LessonDetailScreen } from './components/LearningScreens';
import MealsScreen from './components/MealsScreen';
import ProfileOnboarding from './components/ProfileOnboarding';
import { EMPTY_PROFILE, profileContext, stageFromProfile, type Profile } from './lib/profile';
import AskOpalScreen from './components/AskOpalChat';
import { CareScreen, SavedScreen, SettingsScreen, type DemoRequest } from './components/SecondaryScreens';
import StaffPortal from './components/StaffPortal';
import { SEED_QUEUE, STAFF_TEAM, type QueueItem, type StaffMember } from './data/staffData';
import { INITIAL_CHAT, type ChatMessage } from './lib/askOpal';
import { clearPreferences, freshPreferences, readPreferences, writePreferences } from './lib/localPreferences';

const NAV_ITEMS = [
  { id: 'home', am: 'መነሻ', en: 'Home', icon: Home },
  { id: 'learn', am: 'ትምህርት', en: 'Learn', icon: BookOpen },
  { id: 'meals', am: 'ምግብ', en: 'Meals', icon: CookingPot },
  { id: 'care', am: 'እንክብካቤ', en: 'Care', icon: HeartHandshake },
] as const;

export default function App() {
  const [preferences, setPreferences] = useState(readPreferences);
  const [screen, setScreen] = useState<ScreenId>(preferences.welcomed ? 'home' : 'welcome');
  const [history, setHistory] = useState<ScreenId[]>([]);
  const [profile, setProfile] = useState<Profile | null>(preferences.profile);
  const [stage, setStage] = useState<CareStage>(preferences.profile ? stageFromProfile(preferences.profile) : 'none');
  const [selectedLesson, setSelectedLesson] = useState(LESSONS[0].id);
  const [request, setRequest] = useState<DemoRequest | null>(null);
  const [queue, setQueue] = useState<QueueItem[]>(SEED_QUEUE);
  const [portal, setPortal] = useState(false);
  const [team, setTeam] = useState<StaffMember[]>(STAFF_TEAM);
  const [chat, setChat] = useState<ChatMessage[]>(INITIAL_CHAT);
  const [completed, setCompleted] = useState<string[]>([]);
  const [persistent, setPersistent] = useState(true);
  const [toast, setToast] = useState('');
  const contentRef = useRef<HTMLElement>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lang = preferences.lang;
  const t: Translate = (am, en) => lang === 'am' ? am : en;

  useEffect(() => {
    document.documentElement.lang = lang;
    document.title = 'Trinity Health Solution — A little learning. A lot of care.';
    setPersistent(writePreferences(preferences));
  }, [preferences, lang]);

  useEffect(() => {
    contentRef.current?.scrollTo({ top: 0 });
    contentRef.current?.focus({ preventScroll: true });
  }, [screen, selectedLesson]);

  useEffect(() => () => { if (toastTimer.current) clearTimeout(toastTimer.current); }, []);

  function notify(message: string) {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast(message);
    toastTimer.current = setTimeout(() => setToast(''), 3500);
  }

  function navigate(next: ScreenId) {
    if (screen === next) return;
    setHistory(previous => [...previous, screen]);
    setScreen(next);
  }

  function goBack() {
    const previous = history[history.length - 1];
    setHistory(items => items.slice(0, -1));
    setScreen(previous && previous !== 'welcome' ? previous : 'home');
  }

  function finishOnboarding(nextStage: CareStage) {
    setStage(nextStage === 'prefer_not_to_say' ? 'none' : nextStage);
    setPreferences(previous => ({ ...previous, welcomed: true }));
    setHistory([]);
    setScreen('home');
  }

  function finishProfile(next: Profile | null, remember: boolean) {
    setProfile(next);
    setStage(next ? stageFromProfile(next) : 'none');
    setPreferences(previous => ({ ...previous, welcomed: true, profile: next && remember ? next : null }));
    setHistory([]);
    setScreen('home');
  }

  function toggleSave(id: string) {
    const alreadySaved = preferences.saved.includes(id);
    setPreferences(previous => ({ ...previous, saved: alreadySaved
      ? previous.saved.filter(item => item !== id) : [...previous.saved, id] }));
    notify(alreadySaved ? t('ከስብስብዎ ተወግዷል', 'Note removed from your collection')
      : t('ወደ ስብስብዎ ታክሏል', 'A good note, tucked away'));
  }

  function openLesson(id: string) {
    if (!LESSONS.some(lesson => lesson.id === id)) return;
    setSelectedLesson(id);
    navigate('lesson-detail');
  }

  function setFamilyRequest(next: DemoRequest | null) {
    const requestWithContext = next && { ...next, profileContext: profileContext(profile) };
    setRequest(requestWithContext);
    setQueue(previous => {
      const rest = previous.filter(item => item.source !== 'family');
      if (!requestWithContext) return rest;
      const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
      return [{ id: 'REQ-1050', source: 'family', typeId: requestWithContext.typeId, format: requestWithContext.format, received: `Today · ${time}`, status: 'new', note: '',
        profileContext: requestWithContext.profileContext,
        timeline: [{ label: 'Request received', at: time }] }, ...rest];
    });
  }

  function clearData() {
    const cleared = clearPreferences();
    setPreferences(freshPreferences());
    setStage('none');
    setProfile(null);
    setRequest(null);
    setQueue(SEED_QUEUE);
    setChat(INITIAL_CHAT);
    setCompleted([]);
    setHistory([]);
    setScreen('welcome');
    notify(cleared ? 'Trinity Health Solution data cleared. ውሂብ ጠፍቷል።'
      : 'Session reset. Browser storage could not be cleared; use your browser’s site-data settings.');
  }

  const onboarding = screen === 'welcome' || screen === 'personalize';
  const rootScreen = NAV_ITEMS.some(item => item.id === screen);
  const activeNav = screen === 'lesson-detail' ? 'learn' : screen === 'ask-opal' ? 'care' : screen;
  const common = { lang, t };

  if (portal) return <div className="studio"><div className="device-wrap"><StaffPortal queue={queue} setQueue={setQueue} team={team} setTeam={setTeam} onExit={() => setPortal(false)} /></div></div>;

  return <div className="studio">
    <aside className="studio-story" aria-label="About Trinity Health Solution">
      <div className="studio-brand"><img className="brand-mark" style={{ height: 46 }} src={trinityMark} alt="" /><span>Trinity Health Solution<small>WELLNESS WITHOUT BORDERS</small></span></div>
      <div className="story-body">
        <span className="edition-tag"><span /> WELLNESS WITHOUT BORDERS</span>
        <h2>Better health for<br />every <em>family!</em></h2>
        <p>Your health, our mission. Personalized nutrition therapy, trusted health education, and professional consultations, in person or online, wherever you are.</p>
        <TibebBorder variant="subtle" />
        <div className="story-values"><span><Sprout size={17} />Made for Ethiopian families</span><span><BookOpen size={17} />Open to everyone. No account needed.</span><span><ShieldCheck size={17} />Advancing SDG 3: Good Health and Well-Being</span></div>
      </div>
      <button className="studio-staff" onClick={() => setPortal(true)}><ShieldCheck size={16} />Open the staff portal (demo)</button>
      <div className="studio-footnote"><span>እንክብካቤ ከቤት ይጀምራል።</span><p>Care begins at home.</p></div>
    </aside>
    <div className="device-wrap">
      <div className={`app-shell ${onboarding ? 'onboarding-shell' : ''}`} lang={lang}>
        {screen === 'welcome' ? <header className="welcome-header">
          <div className="brand-lockup"><img className="brand-mark" style={{ height: 34 }} src={trinityMark} alt="" /><span>Trinity Health Solution</span></div>
        </header> : <header className="app-header">
          {!rootScreen ? <IconButton label={t('ተመለስ', 'Go back')} onClick={goBack}><ArrowLeft size={21} /></IconButton> : <img className="brand-mark" style={{ height: 30 }} src={trinityMark} alt="" />}
          <button className="header-wordmark" onClick={() => navigate('home')} aria-label={t('ትሪኒቲ ሄልዝ ሶሉሽን መነሻ', 'Trinity Health Solution home')}>Trinity Health Solution<span>{t('ትንሽ እውቀት፣ ብዙ እንክብካቤ', 'GROWING GOOD, TOGETHER')}</span></button>
          <div className="header-actions">
            <IconButton label={t('የተቀመጡ ትምህርቶች', 'Saved notes')} onClick={() => navigate('saved')}><Bookmark size={19} fill={screen === 'saved' ? 'currentColor' : 'none'} /></IconButton>
            <IconButton label={t('ቅንብሮች', 'Settings')} onClick={() => navigate('settings')}><Settings size={19} /></IconButton>
          </div>
        </header>}
        <main ref={contentRef} className="app-content mobile-scroll" tabIndex={-1}>
          {screen === 'welcome' && <WelcomeScreen {...common} setLang={next => setPreferences(previous => ({ ...previous, lang: next }))}
            onContinue={() => navigate('personalize')} onSkip={() => finishOnboarding('none')} />}
          {screen === 'personalize' && <ProfileOnboarding lang={lang} t={t} initial={profile ?? EMPTY_PROFILE} onFinish={finishProfile} onSkip={() => finishProfile(null, false)} onBack={() => setScreen(preferences.welcomed ? 'home' : 'welcome')} />}
          {screen === 'home' && <HomeScreen {...common} stage={stage} profile={profile} editProfile={() => navigate('personalize')} navigate={navigate} openLesson={openLesson} saved={preferences.saved} toggleSave={toggleSave} />}
          {screen === 'learn' && <LearnScreen {...common} openLesson={openLesson} saved={preferences.saved} toggleSave={toggleSave} />}
          {screen === 'lesson-detail' && <LessonDetailScreen {...common} lesson={LESSONS.find(item => item.id === selectedLesson)!}
            saved={preferences.saved.includes(selectedLesson)} toggleSave={() => toggleSave(selectedLesson)}
            completed={completed.includes(selectedLesson)} onComplete={() => setCompleted(previous => [...previous, selectedLesson])} />}
          {screen === 'meals' && <MealsScreen {...common} />}
          {screen === 'ask-opal' && <AskOpalScreen {...common} chat={chat} setChat={setChat} request={request} setRequest={setFamilyRequest} navigate={navigate} openLesson={openLesson} />}
          {screen === 'care' && <CareScreen {...common} staffStatus={queue.find(item => item.source === 'family')?.status} navigate={navigate} request={request} setRequest={setFamilyRequest} />}
          {screen === 'saved' && <SavedScreen {...common} saved={preferences.saved} toggleSave={toggleSave} openLesson={openLesson} navigate={navigate} persistent={persistent} />}
          {screen === 'settings' && <SettingsScreen {...common} setLang={next => setPreferences(previous => ({ ...previous, lang: next }))}
            stage={stage} clearStage={() => { setStage('none'); setProfile(null); setPreferences(previous => ({ ...previous, profile: null })); notify(t('የክፍለ ጊዜ ምርጫ ተወግዷል', 'Session personalization removed')); }}
            navigate={navigate} clearData={clearData} persistent={persistent} openStaff={() => setPortal(true)} />}
        </main>
        {!onboarding && screen !== 'ask-opal' && <button className="chat-fab" onClick={() => navigate('ask-opal')} aria-label={t('ኦፓልን ይጠይቁ', 'Ask Opal')}>
          <MessageCircle size={22} /><span>{t('ኦፓልን ጠይቅ', 'Ask Opal')}</span></button>}
        {toast && <div className="toast" role="status"><Check size={17} /><span>{toast}</span></div>}
        {!persistent && screen !== 'settings' && <div className="storage-warning">{t('ማከማቻ አይገኝም፤ ምርጫዎች ጊዜያዊ ናቸው።', 'Storage unavailable; preferences are session-only.')}</div>}
        {!onboarding && <nav className="bottom-nav" aria-label={t('ዋና መምሪያ', 'Main navigation')}>
          {NAV_ITEMS.map(item => <button key={item.id} className={activeNav === item.id ? 'active' : ''} aria-current={activeNav === item.id ? 'page' : undefined} onClick={() => navigate(item.id)}>
            <span className="nav-icon"><item.icon size={22} strokeWidth={activeNav === item.id ? 1.9 : 1.5} /></span><span>{lang === 'am' ? item.am : item.en}</span>
          </button>)}
        </nav>}
        <div className="phone-home-indicator" aria-hidden="true"><span /></div>
      </div>
    </div>
  </div>;
}

function WelcomeScreen({ lang, t, setLang, onContinue, onSkip }: {
  lang: Language;
  t: Translate;
  setLang: (lang: Language) => void;
  onContinue: () => void;
  onSkip: () => void;
}) {
  return <div className="welcome-page">
    <div className="welcome-art"><img src="https://images.unsplash.com/photo-1536064479547-7ee40b74b807?auto=format&fit=crop&w=900&h=560&q=75" alt="A health worker in a white coat consulting a young patient" /><span className="art-note">{t('ጤና ያለ ድንበር 🌍', 'WELLNESS WITHOUT BORDERS 🌍')}</span></div>
    <div className="welcome-title"><p className="eyebrow">{t('እንኳን ወደ ትሪኒቲ ሄልዝ ሶሉሽን መጡ', 'WELCOME TO TRINITY HEALTH SOLUTION')}</p>
      <h1 className="editorial">{t('ለእያንዳንዱ ቤተሰብ\nየተሻለ ጤና!', 'Better health\nfor every family!')}</h1>
      <p>{t('ጤናዎ፣ ተልዕኳችን። ግላዊ የአመጋገብ ቴራፒ፣ ታማኝ የጤና ትምህርት እና ሙያዊ ምክክር በአካል ወይም በበይነመረብ፣ ባሉበት ሆነው ያግኙ።', 'Your health, our mission. Access personalized nutrition therapy, trusted health education, and professional consultations, in person or online, wherever you are.')}</p>
      <p className="welcome-sdg">{t('አብረን የዘላቂ ልማት ግብ 3 (ጥሩ ጤናና ደህንነት) እናሳካለን፤ ጤናማ ሕይወት ለሁሉም ተደራሽ እንዲሆን።', 'Together, we are advancing SDG 3: Good Health and Well-Being, making healthier lives accessible to everyone.')}</p>
      <p className="welcome-journey">{t('ወደ የተሻለ ጤና የሚደረገው ጉዞዎ እዚህ ይጀምራል!', 'Your journey to better health starts here!')}</p>
      <div className="welcome-pillars">
        <span><BookOpen size={16} />{t('ትምህርት', 'Education')}</span>
        <span><Stethoscope size={16} />{t('ምክክር', 'Consultation')}</span>
        <span><HeartHandshake size={16} />{t('ቴራፒ', 'Therapy')}</span>
      </div>
    </div>
    <TibebBorder variant="subtle" />
    <div className="welcome-language"><p className="field-label">{t('ቋንቋዎን ይምረጡ', 'Make yourself at home in')}</p>
      <div className="language-switch" role="group" aria-label="Choose your language">
        <button className={lang === 'am' ? 'active' : ''} aria-pressed={lang === 'am'} onClick={() => setLang('am')}><span lang="am">አማርኛ</span><small>Amharic</small>{lang === 'am' && <Check size={16} />}</button>
        <button className={lang === 'en' ? 'active' : ''} aria-pressed={lang === 'en'} onClick={() => setLang('en')}><span>English</span><small lang="am">እንግሊዝኛ</small>{lang === 'en' && <Check size={16} />}</button>
      </div>
    </div>
    <Button onClick={onContinue}>{t('አብረን እንጀምር', 'Let’s begin together')}<ArrowRight size={19} /></Button>
    <Button variant="quiet" onClick={onSkip}>{t('በቀጥታ ወደ ትምህርቶች', 'Just here to explore? Skip the setup')}<ChevronRight size={14} /></Button>
    <p className="welcome-privacy"><ShieldCheck size={14} />{t('ነፃ መማር። መመዝገብ አያስፈልግም።', 'Free to learn. No account. No personal details.')}</p>
  </div>;
}
